import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { initDb, getDb } from './index.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function seed() {
  await initDb();
  const { db, run, all, get } = getDb();

  const schemaPath = path.join(__dirname, 'schema.sql');
  const schema = fs.readFileSync(schemaPath, 'utf8');
  await new Promise((resolve, reject) => db.exec(schema, (err) => (err ? reject(err) : resolve())));

  // Demographics
  const demographics = ['general','men','women','children','elderly'];
  for (const name of demographics) {
    await run(db, 'INSERT OR IGNORE INTO demographics(name) VALUES (?)', [name]);
  }

  // Minimal but representative seed data (extensible)
  const diseases = [
    { name: 'Common Cold', description: 'Viral upper respiratory infection causing runny nose, sore throat, cough.', category: 'Respiratory' },
    { name: 'Type 2 Diabetes', description: 'Metabolic disorder leading to high blood sugar due to insulin resistance.', category: 'Endocrine' },
    { name: 'Iron Deficiency Anemia', description: 'Low hemoglobin due to insufficient iron.', category: 'Hematology' },
    { name: 'Preeclampsia', description: 'Pregnancy-related condition with high blood pressure and organ dysfunction.', category: 'Obstetrics' },
    { name: 'Otitis Media (Ear Infection)', description: 'Middle ear infection common in children.', category: 'Pediatrics' },
    // Women’s health
    { name: 'Polycystic Ovary Syndrome (PCOS)', description: 'Hormonal disorder causing irregular periods, acne, weight gain, and infertility.', category: 'Gynecology' },
    { name: 'Dysmenorrhea (Painful Periods)', description: 'Cramping lower abdominal pain during menstruation.', category: 'Gynecology' },
    { name: 'Endometriosis', description: 'Endometrial-like tissue outside the uterus causing pelvic pain and infertility.', category: 'Gynecology' },
    { name: 'Vaginal Candidiasis (Yeast Infection)', description: 'Candida overgrowth causing itching, discharge, irritation.', category: 'Gynecology' },
    { name: 'Urinary Tract Infection (Women)', description: 'Infection of urinary tract causing dysuria, frequency, urgency.', category: 'Gynecology' },
    { name: 'Pelvic Inflammatory Disease (PID)', description: 'Ascending infection of reproductive organs causing pelvic pain and fever.', category: 'Gynecology' },
    { name: 'Menopause', description: 'Natural cessation of menses with vasomotor symptoms and urogenital changes.', category: 'Gynecology' },
    { name: 'Gestational Diabetes', description: 'Glucose intolerance first recognized during pregnancy.', category: 'Obstetrics' },
    { name: 'Postpartum Depression', description: 'Depression following childbirth impacting mood and function.', category: 'Obstetrics' },
    { name: 'Mastitis (Breastfeeding)', description: 'Breast tissue inflammation/infection in lactation causing pain, redness, fever.', category: 'Obstetrics' }
  ];

  for (const d of diseases) {
    await run(db, 'INSERT OR IGNORE INTO diseases(name, description, category) VALUES (?,?,?)', [d.name, d.description, d.category]);
  }

  const symptomNames = [
    'Runny nose','Sore throat','Cough','Fever','Fatigue','Frequent urination','Increased thirst','Blurred vision','Pale skin','Dizziness','Headache','High blood pressure','Upper right abdominal pain','Ear pain','Irritability in children',
    // Women’s health common symptoms
    'Irregular periods','Pelvic pain','Painful periods','Heavy menstrual bleeding','Vaginal itching','Abnormal vaginal discharge','Painful intercourse','Urinary burning','Urinary urgency','Hot flashes','Night sweats','Mood changes','Breast pain','Breast redness'
  ];
  for (const s of symptomNames) {
    await run(db, 'INSERT OR IGNORE INTO symptoms(name) VALUES (?)', [s]);
  }

  async function idOf(table, name) {
    const row = await get(db, `SELECT id FROM ${table} WHERE name = ?`, [name]);
    return row?.id;
  }

  // Link disease to symptoms
  const links = [
    ['Common Cold','Runny nose','common'],
    ['Common Cold','Sore throat','common'],
    ['Common Cold','Cough','common'],
    ['Common Cold','Fever','occasional'],
    ['Type 2 Diabetes','Frequent urination','common'],
    ['Type 2 Diabetes','Increased thirst','common'],
    ['Type 2 Diabetes','Blurred vision','occasional'],
    ['Iron Deficiency Anemia','Fatigue','common'],
    ['Iron Deficiency Anemia','Pale skin','common'],
    ['Iron Deficiency Anemia','Dizziness','occasional'],
    ['Preeclampsia','High blood pressure','common'],
    ['Preeclampsia','Headache','common'],
    ['Preeclampsia','Upper right abdominal pain','occasional'],
    ['Otitis Media (Ear Infection)','Ear pain','common'],
    ['Otitis Media (Ear Infection)','Fever','occasional'],
    ['Otitis Media (Ear Infection)','Irritability in children','common'],
    // Women’s health links
    ['Polycystic Ovary Syndrome (PCOS)','Irregular periods','common'],
    ['Polycystic Ovary Syndrome (PCOS)','Acne','occasional'],
    ['Polycystic Ovary Syndrome (PCOS)','Weight gain','occasional'],
    ['Dysmenorrhea (Painful Periods)','Painful periods','common'],
    ['Dysmenorrhea (Painful Periods)','Pelvic pain','common'],
    ['Endometriosis','Pelvic pain','common'],
    ['Endometriosis','Painful intercourse','occasional'],
    ['Vaginal Candidiasis (Yeast Infection)','Vaginal itching','common'],
    ['Vaginal Candidiasis (Yeast Infection)','Abnormal vaginal discharge','common'],
    ['Urinary Tract Infection (Women)','Urinary burning','common'],
    ['Urinary Tract Infection (Women)','Urinary urgency','common'],
    ['Pelvic Inflammatory Disease (PID)','Pelvic pain','common'],
    ['Pelvic Inflammatory Disease (PID)','Fever','occasional'],
    ['Menopause','Hot flashes','common'],
    ['Menopause','Night sweats','common'],
    ['Postpartum Depression','Mood changes','common'],
    ['Mastitis (Breastfeeding)','Breast pain','common'],
    ['Mastitis (Breastfeeding)','Breast redness','common']
  ];

  for (const [dName, sName, commonality] of links) {
    const did = await idOf('diseases', dName);
    const sid = await idOf('symptoms', sName);
    if (did && sid) {
      await run(db, 'INSERT OR IGNORE INTO disease_symptoms(disease_id, symptom_id, commonality) VALUES (?,?,?)', [did, sid, commonality]);
    }
  }

  // Treatments
  const treatments = [
    ['Common Cold', 'Supportive care', 'Rest, hydration, saline nasal sprays, humidifier. OTC analgesics as needed.'],
    ['Type 2 Diabetes', 'Lifestyle + Metformin', 'Dietary changes, physical activity, weight management, first-line Metformin unless contraindicated.'],
    ['Iron Deficiency Anemia', 'Iron supplementation', 'Oral iron (e.g., ferrous sulfate) with vitamin C; address bleeding sources.'],
    ['Preeclampsia', 'Obstetric management', 'Close monitoring, antihypertensives, magnesium sulfate for seizure prophylaxis, delivery planning.'],
    ['Otitis Media (Ear Infection)', 'Analgesia +/- antibiotics', 'Pain control; consider amoxicillin depending on severity and age.'],
    // Women’s health treatments
    ['Polycystic Ovary Syndrome (PCOS)', 'Lifestyle + hormonal regulation', 'Weight management, exercise, combined oral contraceptives for cycle regulation, metformin if insulin resistance.'],
    ['Dysmenorrhea (Painful Periods)', 'NSAIDs and supportive', 'NSAIDs (e.g., ibuprofen) started at onset; heat therapy; consider hormonal contraception.'],
    ['Endometriosis', 'Medical and surgical options', 'NSAIDs, hormonal therapy (OCPs, progestins), GnRH analogs; laparoscopy for diagnosis and treatment if needed.'],
    ['Vaginal Candidiasis (Yeast Infection)', 'Antifungal therapy', 'Topical azoles or oral fluconazole as per guidelines.'],
    ['Urinary Tract Infection (Women)', 'Antibiotic therapy', 'Nitrofurantoin, trimethoprim-sulfamethoxazole, or fosfomycin depending on local resistance and patient factors.'],
    ['Pelvic Inflammatory Disease (PID)', 'Antibiotic therapy', 'Outpatient: ceftriaxone IM + doxycycline + metronidazole; inpatient if severe.'],
    ['Menopause', 'Symptom management', 'Lifestyle changes; hormone therapy when appropriate after risk assessment; non-hormonal options for hot flashes.'],
    ['Gestational Diabetes', 'Diet + monitoring +/- insulin', 'Medical nutrition therapy, glucose monitoring; insulin if required; obstetric follow-up.'],
    ['Postpartum Depression', 'Support + therapy +/- meds', 'Screening, counseling/therapy; SSRIs if indicated; monitor mother-infant safety.'],
    ['Mastitis (Breastfeeding)', 'Antibiotics + continued breastfeeding', 'Warm compresses, effective milk removal; antibiotics covering Staph aureus; evaluate for abscess if not improving.']
  ];

  for (const [dName, title, details] of treatments) {
    const did = await idOf('diseases', dName);
    if (did) await run(db, 'INSERT OR IGNORE INTO treatments(disease_id, title, details) VALUES (?,?,?)', [did, title, details]);
  }

  // Medications
  const meds = [
    { name: 'Metformin', generic_name: 'Metformin', uses: 'Type 2 Diabetes management', dosage: '500 mg once or twice daily, titrate', side_effects: 'GI upset, lactic acidosis (rare)', warnings: 'Avoid in severe renal impairment' },
    { name: 'Amoxicillin', generic_name: 'Amoxicillin', uses: 'Bacterial infections including otitis media', dosage: '500 mg every 8 hours (adults); pediatric dosing by weight', side_effects: 'Rash, diarrhea, allergic reactions', warnings: 'Penicillin allergy contraindication' },
    { name: 'Ferrous Sulfate', generic_name: 'Iron', uses: 'Iron deficiency anemia', dosage: '325 mg (65 mg elemental iron) 1-3x daily', side_effects: 'Constipation, dark stools, nausea', warnings: 'Keep away from children; overdose risk' },
    // Women’s health related medications (general guidance only)
    { name: 'Ibuprofen', generic_name: 'Ibuprofen', uses: 'Painful periods, pelvic pain', dosage: '200–400 mg every 6–8 hours (max 1200 mg/day OTC)', side_effects: 'GI upset, ulcer risk', warnings: 'Avoid in late pregnancy; caution in ulcers/kidney disease' },
    { name: 'Combined Oral Contraceptive', generic_name: 'Ethinyl estradiol/Progestin', uses: 'Cycle regulation, dysmenorrhea, PCOS symptoms', dosage: 'One tablet daily as directed', side_effects: 'Nausea, headache, spotting', warnings: 'VTE risk; avoid with certain migraine/HTN/smoking over 35' },
    { name: 'Fluconazole', generic_name: 'Fluconazole', uses: 'Vaginal candidiasis', dosage: '150 mg single dose (per local guideline)', side_effects: 'Nausea, rash, LFT changes', warnings: 'Drug interactions; avoid in pregnancy unless advised' },
    { name: 'Nitrofurantoin', generic_name: 'Nitrofurantoin', uses: 'Uncomplicated cystitis', dosage: '100 mg twice daily for 5 days (adults)', side_effects: 'GI upset, headache', warnings: 'Avoid in late pregnancy and severe renal impairment' }
  ];
  for (const m of meds) {
    await run(db, 'INSERT OR IGNORE INTO medications(name, generic_name, uses, dosage, side_effects, warnings) VALUES (?,?,?,?,?,?)', [m.name, m.generic_name, m.uses, m.dosage, m.side_effects, m.warnings]);
  }

  const medMap = [
    ['Metformin','Type 2 Diabetes'],
    ['Amoxicillin','Otitis Media (Ear Infection)'],
    ['Ferrous Sulfate','Iron Deficiency Anemia'],
    // Women’s health mappings
    ['Ibuprofen','Dysmenorrhea (Painful Periods)'],
    ['Combined Oral Contraceptive','Polycystic Ovary Syndrome (PCOS)'],
    ['Fluconazole','Vaginal Candidiasis (Yeast Infection)'],
    ['Nitrofurantoin','Urinary Tract Infection (Women)']
  ];
  for (const [mName, dName] of medMap) {
    const mid = await idOf('medications', mName);
    const did = await idOf('diseases', dName);
    if (mid && did) await run(db, 'INSERT OR IGNORE INTO medication_diseases(medication_id, disease_id) VALUES (?,?)', [mid, did]);
  }

  // Demographic mapping
  const demMap = [
    ['Common Cold','general','Self-limited across all ages.'],
    ['Type 2 Diabetes','elderly','Higher prevalence; comorbidities common.'],
    ['Iron Deficiency Anemia','women','Common in menstruating and pregnant women.'],
    ['Preeclampsia','women','Pregnancy-related only.'],
    ['Otitis Media (Ear Infection)','children','Very common in young children.'],
    // Women’s health demographics
    ['Polycystic Ovary Syndrome (PCOS)','women','Affects reproductive-age women; metabolic risks.'],
    ['Dysmenorrhea (Painful Periods)','women','Common in adolescents and young women.'],
    ['Endometriosis','women','Chronic pelvic pain and infertility risk.'],
    ['Vaginal Candidiasis (Yeast Infection)','women','Common; recurrent if risk factors.'],
    ['Urinary Tract Infection (Women)','women','Very common; prevention counseling helpful.'],
    ['Pelvic Inflammatory Disease (PID)','women','Sexually active women; consider STI screening.'],
    ['Menopause','women','Perimenopause and postmenopause symptom management.'],
    ['Gestational Diabetes','women','Occurs during pregnancy; obstetric monitoring needed.'],
    ['Postpartum Depression','women','Emerges after delivery; screen and support.'],
    ['Mastitis (Breastfeeding)','women','Typically within first few weeks postpartum.']
  ];
  async function demoId(name) { const row = await get(db, 'SELECT id FROM demographics WHERE name=?', [name]); return row?.id; }
  for (const [dName, demName, notes] of demMap) {
    const did = await idOf('diseases', dName);
    const demid = await demoId(demName);
    if (did && demid) await run(db, 'INSERT OR IGNORE INTO disease_demographics(disease_id, demographic_id, notes) VALUES (?,?,?)', [did, demid, notes]);
  }

  // Remedies and prevention
  const remedies = [
    ['Common Cold','Hydration, rest, honey for cough (>1 yr)','Saline nasal rinse, steam inhalation','Hand hygiene, avoid sick contacts','Seek care if high fever >3 days, shortness of breath'],
    ['Type 2 Diabetes','Balanced diet, regular exercise, weight loss','Monitor blood glucose, foot care','Routine screening, maintain healthy BMI','Seek care for symptoms of hyperglycemia or hypoglycemia'],
    ['Iron Deficiency Anemia','Iron-rich diet (red meat, legumes), vitamin C','Avoid tea/coffee near iron doses','Treat menstrual or GI blood loss','Seek care for severe fatigue, chest pain, syncope'],
    ['Preeclampsia','Prenatal care, BP monitoring','Rest as advised by obstetrician','Aspirin prophylaxis in high-risk as directed','Seek urgent care for severe headache, vision changes, RUQ pain'],
    ['Otitis Media (Ear Infection)','Pain control, warm compress','Nasal saline, observe if mild','Vaccinations, avoid smoke exposure','Seek care for severe pain, persistent fever, drainage'],
    // Women’s health remedies
    ['Polycystic Ovary Syndrome (PCOS)','Weight management, balanced diet, regular exercise','Manage stress, sleep hygiene','Screen for metabolic syndrome; long-term follow-up','Seek care for infertility, severe acne/hirsutism, metabolic issues'],
    ['Dysmenorrhea (Painful Periods)','Scheduled NSAIDs at onset, heat therapy','Light activity, relaxation techniques','Track cycles; consider hormonal options if frequent','Seek care if pain is severe, persistent, or associated with heavy bleeding'],
    ['Endometriosis','Medical therapy adherence, pain management','Heat packs, pelvic floor relaxation','Fertility counseling if needed','Seek care for persistent severe pelvic pain or fertility concerns'],
    ['Vaginal Candidiasis (Yeast Infection)','Cotton underwear, keep area dry','Avoid irritants (douches, perfumed soaps)','Good glycemic control if diabetic','Seek care for recurrent infections or severe symptoms'],
    ['Urinary Tract Infection (Women)','Hydration, frequent voiding','Post-coital voiding, consider cranberry if helpful','Hygiene education, avoid spermicides if recurrent','Seek care for fever, flank pain, or recurrent UTIs'],
    ['Pelvic Inflammatory Disease (PID)','Medication adherence','Partner evaluation and treatment','Safe sex practices, STI screening','Seek urgent care for severe pain, high fever, vomiting'],
    ['Menopause','Healthy lifestyle, layered clothing','Vaginal moisturizers/lubricants for dryness','Discuss HRT risks/benefits with clinician','Seek care for heavy bleeding after menopause or severe symptoms'],
    ['Gestational Diabetes','Dietary counseling, glucose logs','Light regular exercise as approved','Antenatal follow-up, plan postpartum screening','Seek care for high readings or symptoms of hyperglycemia'],
    ['Postpartum Depression','Support network, rest','Mindfulness, counseling','Early screening and follow-up','Seek urgent care for suicidal thoughts or inability to care for baby'],
    ['Mastitis (Breastfeeding)','Frequent emptying, warm compress','Good latch; continue breastfeeding','Breastfeeding support resources','Seek care for high fever, spreading redness, or if not improving in 24–48h']
  ];
  for (const [dName, lifestyle, home, prevention, when] of remedies) {
    const did = await idOf('diseases', dName);
    if (did) await run(db, 'INSERT OR IGNORE INTO remedies(disease_id, lifestyle, home_remedies, prevention, when_to_seek_care) VALUES (?,?,?,?,?)', [did, lifestyle, home, prevention, when]);
  }

  console.log('Database seeded successfully.');
}

seed().catch((e) => {
  console.error('Seeding error:', e);
  process.exit(1);
});
