import { initDb, getDb } from './index.js';

async function seedBiochem() {
  await initDb();
  const { db, run, get } = getDb();

  // Create tables if not exist
  await run(db, `CREATE TABLE IF NOT EXISTS chemicals (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT UNIQUE NOT NULL,
    description TEXT,
    role TEXT,
    sources TEXT,
    clinical_significance TEXT,
    normal_range TEXT
  )`);

  await run(db, `CREATE TABLE IF NOT EXISTS enzymes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT UNIQUE NOT NULL,
    description TEXT,
    function TEXT,
    tissue_sources TEXT,
    clinical_significance TEXT,
    normal_range TEXT
  )`);

  // Chemicals (common clinical analytes)
  const chemicals = [
    {
      name: 'Glucose',
      description: 'Primary energy source in blood.',
      role: 'Energy metabolism',
      sources: 'Dietary carbohydrates; hepatic gluconeogenesis',
      clinical_significance: 'Hyperglycemia in diabetes; hypoglycemia can cause neuroglycopenic symptoms',
      normal_range: 'Fasting ~70–99 mg/dL (3.9–5.5 mmol/L)'
    },
    {
      name: 'Cholesterol',
      description: 'Lipid essential for cell membranes and steroid synthesis.',
      role: 'Membrane structure; steroid/vitamin D/bile acid precursor',
      sources: 'Endogenous hepatic synthesis; dietary intake',
      clinical_significance: 'Elevated LDL associated with ASCVD risk',
      normal_range: 'Total <200 mg/dL desirable'
    },
    {
      name: 'Creatinine',
      description: 'Waste product from muscle creatine phosphate.',
      role: 'Marker of kidney function (GFR estimation)',
      sources: 'Muscle metabolism',
      clinical_significance: 'Elevated in renal impairment',
      normal_range: '~0.6–1.3 mg/dL (varies by lab, sex, muscle mass)'
    },
    {
      name: 'Urea (BUN)',
      description: 'Nitrogenous waste from protein metabolism.',
      role: 'Renal excretion marker',
      sources: 'Hepatic urea cycle',
      clinical_significance: 'Elevated in renal dysfunction, dehydration, GI bleed',
      normal_range: '~7–20 mg/dL'
    }
  ];

  for (const c of chemicals) {
    await run(db, 'INSERT OR IGNORE INTO chemicals(name, description, role, sources, clinical_significance, normal_range) VALUES (?,?,?,?,?,?)', [c.name, c.description, c.role, c.sources, c.clinical_significance, c.normal_range]);
  }

  // Enzymes (common clinical enzymes)
  const enzymes = [
    {
      name: 'ALT (Alanine Aminotransferase)',
      description: 'Hepatocellular enzyme.',
      function: 'Catalyzes transamination of alanine to pyruvate',
      tissue_sources: 'Liver (predominant)',
      clinical_significance: 'Elevated in hepatocellular injury (e.g., hepatitis)',
      normal_range: '~7–56 U/L (varies by lab)'
    },
    {
      name: 'AST (Aspartate Aminotransferase)',
      description: 'Enzyme present in liver, muscle, heart.',
      function: 'Catalyzes transamination of aspartate to oxaloacetate',
      tissue_sources: 'Liver, cardiac, skeletal muscle',
      clinical_significance: 'Elevated in hepatic and muscle injury',
      normal_range: '~10–40 U/L (varies)'
    },
    {
      name: 'ALP (Alkaline Phosphatase)',
      description: 'Enzyme associated with bile ducts and bone.',
      function: 'Hydrolyzes phosphate esters in alkaline conditions',
      tissue_sources: 'Biliary tract, bone (osteoblasts), placenta',
      clinical_significance: 'Elevated in cholestasis or increased bone turnover',
      normal_range: '~44–147 U/L (varies)'
    },
    {
      name: 'Amylase',
      description: 'Digestive enzyme for carbohydrates.',
      function: 'Hydrolyzes starch to sugars',
      tissue_sources: 'Pancreas and salivary glands',
      clinical_significance: 'Elevated in pancreatitis and salivary gland disorders',
      normal_range: '~30–110 U/L (varies)'
    },
    {
      name: 'Lipase',
      description: 'Digestive enzyme for fats.',
      function: 'Hydrolyzes triglycerides',
      tissue_sources: 'Pancreas',
      clinical_significance: 'More specific than amylase for pancreatitis when elevated',
      normal_range: '~0–160 U/L (varies)'
    }
  ];

  for (const e of enzymes) {
    await run(db, 'INSERT OR IGNORE INTO enzymes(name, description, function, tissue_sources, clinical_significance, normal_range) VALUES (?,?,?,?,?,?)', [e.name, e.description, e.function, e.tissue_sources, e.clinical_significance, e.normal_range]);
  }

  console.log('Biochemical seed completed.');
}

seedBiochem().catch((e) => { console.error('Seed biochem error:', e); process.exit(1); });
