import { initDb, getDb } from './index.js';

async function seedExtra() {
  await initDb();
  const { db, run, all, get } = getDb();

  // Diseases (Orthopedics and Dermatology)
  const addDiseases = [
    { name: 'Osteoarthritis', description: 'Degenerative joint disease causing pain, stiffness, and reduced function.', category: 'Orthopedics' },
    { name: 'Long Bone Fracture', description: 'Break in a long bone (e.g., femur, tibia, humerus) usually due to trauma.', category: 'Orthopedics' },
    { name: 'Low Back Pain (Mechanical)', description: 'Common musculoskeletal pain in the lumbar region without red flags.', category: 'Orthopedics' },
    { name: 'Psoriasis', description: 'Chronic immune-mediated skin disease with erythematous scaly plaques.', category: 'Dermatology' },
    { name: 'Atopic Dermatitis (Eczema)', description: 'Pruritic, chronic inflammatory skin condition with xerosis and eczematous lesions.', category: 'Dermatology' },
    { name: 'Acne Vulgaris', description: 'Inflammatory disease of the pilosebaceous unit with comedones and papulopustules.', category: 'Dermatology' },
    { name: 'Cellulitis', description: 'Acute bacterial infection of the skin and subcutaneous tissue with erythema and warmth.', category: 'Dermatology' },
    { name: 'Contact Dermatitis', description: 'Skin inflammation due to irritant or allergic contact exposure.', category: 'Dermatology' }
  ];
  for (const d of addDiseases) {
    await run(db, 'INSERT OR IGNORE INTO diseases(name, description, category) VALUES (?,?,?)', [d.name, d.description, d.category]);
  }

  // Symptoms
  const addSymptoms = [
    'Joint pain','Joint stiffness','Joint swelling','Limited mobility','Morning stiffness','Crepitus','Bone pain','Deformity','Back pain','Radiating leg pain','Skin rash','Itching','Scaling','Redness','Warmth','Pustules','Papules','Dry skin','Blisters'
  ];
  for (const s of addSymptoms) {
    await run(db, 'INSERT OR IGNORE INTO symptoms(name) VALUES (?)', [s]);
  }

  async function idOf(table, name) { const row = await get(db, `SELECT id FROM ${table} WHERE name=?`, [name]); return row?.id; }
  async function sid(name) { const row = await get(db, 'SELECT id FROM symptoms WHERE name=?', [name]); return row?.id; }

  // Disease-symptom links
  const addLinks = [
    ['Osteoarthritis','Joint pain','common'],
    ['Osteoarthritis','Joint stiffness','common'],
    ['Osteoarthritis','Limited mobility','common'],
    ['Osteoarthritis','Crepitus','occasional'],
    ['Long Bone Fracture','Bone pain','common'],
    ['Long Bone Fracture','Deformity','occasional'],
    ['Long Bone Fracture','Warmth','occasional'],
    ['Low Back Pain (Mechanical)','Back pain','common'],
    ['Low Back Pain (Mechanical)','Radiating leg pain','occasional'],
    ['Psoriasis','Scaling','common'],
    ['Psoriasis','Redness','common'],
    ['Psoriasis','Itching','occasional'],
    ['Atopic Dermatitis (Eczema)','Itching','common'],
    ['Atopic Dermatitis (Eczema)','Dry skin','common'],
    ['Atopic Dermatitis (Eczema)','Skin rash','common'],
    ['Acne Vulgaris','Papules','common'],
    ['Acne Vulgaris','Pustules','common'],
    ['Contact Dermatitis','Redness','common'],
    ['Contact Dermatitis','Blisters','occasional'],
    ['Cellulitis','Redness','common'],
    ['Cellulitis','Warmth','common'],
    ['Cellulitis','Skin rash','occasional']
  ];
  for (const [dName, sName, commonality] of addLinks) {
    const did = await idOf('diseases', dName);
    const symptomId = await sid(sName);
    if (did && symptomId) {
      await run(db, 'INSERT OR IGNORE INTO disease_symptoms(disease_id, symptom_id, commonality) VALUES (?,?,?)', [did, symptomId, commonality]);
    }
  }

  // Treatments
  const addTreatments = [
    ['Osteoarthritis','Activity + analgesia','Weight management, physical therapy; analgesics (acetaminophen/NSAIDs) as appropriate; joint protection.'],
    ['Long Bone Fracture','Immobilization + reduction','Immobilize/splint; analgesia; urgent orthopedic evaluation; reduction/surgery as indicated.'],
    ['Low Back Pain (Mechanical)','Conservative therapy','Activity as tolerated, heat, NSAIDs/acetaminophen, short-term muscle relaxant, red-flag screening.'],
    ['Psoriasis','Topical therapy','Topical corticosteroids and vitamin D analogs; emollients; refer for phototherapy/systemic therapy if severe.'],
    ['Atopic Dermatitis (Eczema)','Skin care + anti-inflammatory','Regular emollients, trigger avoidance; topical corticosteroids or calcineurin inhibitors for flares.'],
    ['Acne Vulgaris','Topical/systemic options','Topical retinoids +/- benzoyl peroxide; consider topical antibiotics; oral agents if moderate-to-severe.'],
    ['Cellulitis','Antibiotic therapy','Oral antibiotics targeting streptococci/staphylococci (e.g., cephalexin) if mild; IV if severe. Elevation and mark margins.'],
    ['Contact Dermatitis','Avoidance + topical steroids','Identify/avoid offending agent; topical corticosteroids; emollients; consider patch testing for recurrent cases.']
  ];
  for (const [dName, title, details] of addTreatments) {
    const did = await idOf('diseases', dName);
    if (did) await run(db, 'INSERT OR IGNORE INTO treatments(disease_id, title, details) VALUES (?,?,?)', [did, title, details]);
  }

  // Medications
  const addMeds = [
    { name: 'Naproxen', generic_name: 'Naproxen', uses: 'Musculoskeletal pain and osteoarthritis', dosage: '250–500 mg twice daily with food (adult)', side_effects: 'GI upset, ulcer risk', warnings: 'Avoid in late pregnancy; caution in ulcers/renal disease' },
    { name: 'Topical Hydrocortisone', generic_name: 'Hydrocortisone', uses: 'Mild eczema/contact dermatitis (topical steroid)', dosage: 'Apply thin layer 1–2x daily to affected areas', side_effects: 'Skin atrophy with prolonged use', warnings: 'Avoid prolonged use on face/folds without guidance' },
    { name: 'Adapalene', generic_name: 'Adapalene', uses: 'Topical retinoid for acne', dosage: 'Apply thin layer nightly as tolerated', side_effects: 'Irritation, dryness, photosensitivity', warnings: 'Avoid in pregnancy unless advised; use sunscreen' },
    { name: 'Cephalexin', generic_name: 'Cephalexin', uses: 'Mild cellulitis, skin/soft tissue infections', dosage: '500 mg every 6 hours (adult) per local guidance', side_effects: 'GI upset, rash', warnings: 'Beta-lactam allergy contraindication' }
  ];
  for (const m of addMeds) {
    await run(db, 'INSERT OR IGNORE INTO medications(name, generic_name, uses, dosage, side_effects, warnings) VALUES (?,?,?,?,?,?)', [m.name, m.generic_name, m.uses, m.dosage, m.side_effects, m.warnings]);
  }

  // Medication-disease mapping
  const addMedMap = [
    ['Naproxen','Osteoarthritis'],
    ['Topical Hydrocortisone','Atopic Dermatitis (Eczema)'],
    ['Topical Hydrocortisone','Contact Dermatitis'],
    ['Adapalene','Acne Vulgaris'],
    ['Cephalexin','Cellulitis']
  ];
  for (const [mName, dName] of addMedMap) {
    const mid = await idOf('medications', mName);
    const did = await idOf('diseases', dName);
    if (mid && did) await run(db, 'INSERT OR IGNORE INTO medication_diseases(medication_id, disease_id) VALUES (?,?)', [mid, did]);
  }

  // Demographic mapping
  const addDemMap = [
    ['Osteoarthritis','elderly','Very common with aging; focus on function and fall prevention.'],
    ['Low Back Pain (Mechanical)','general','Screen for red flags (trauma, fever, weight loss, neurologic deficits).'],
    ['Atopic Dermatitis (Eczema)','children','Common in children; moisturization and gentle skin care are key.'],
    ['Acne Vulgaris','general','Common in adolescents/young adults; consider pregnancy status before retinoids.'],
    ['Psoriasis','general','Chronic course; consider comorbidities (metabolic syndrome).'],
    ['Cellulitis','general','Mark margins; seek care if fever or rapidly spreading redness.'],
    ['Long Bone Fracture','general','Urgent orthopedic evaluation required.'],
    ['Contact Dermatitis','general','Identify and avoid triggers; occupational review if recurrent.']
  ];
  for (const [dName, demName, notes] of addDemMap) {
    const did = await idOf('diseases', dName);
    const demRow = await get(db, 'SELECT id FROM demographics WHERE name=?', [demName]);
    const demid = demRow?.id;
    if (did && demid) await run(db, 'INSERT OR IGNORE INTO disease_demographics(disease_id, demographic_id, notes) VALUES (?,?,?)', [did, demid, notes]);
  }

  // Remedies
  const addRemedies = [
    ['Osteoarthritis','Low-impact exercise, weight loss, joint protection','Heat/cold packs, assistive devices as needed','Prevent falls, maintain activity','Seek care for severe pain, swelling, or locking/giving way'],
    ['Long Bone Fracture','Immobilize and minimize movement','Apply cold pack through cloth; avoid food/drink if surgery likely','Use protective gear; safe environment','Seek emergency care immediately'],
    ['Low Back Pain (Mechanical)','Stay active; core strengthening','Heat therapy; short-term NSAIDs/acetaminophen; posture care','Proper lifting, ergonomic workspace','Seek care for weakness, bladder/bowel dysfunction, fever, trauma'],
    ['Psoriasis','Regular emollients; stress reduction','Short contact showers; avoid harsh soaps','Weight control; avoid smoking; manage triggers','Seek care if widespread, joint pains (psoriatic arthritis), or infection signs'],
    ['Atopic Dermatitis (Eczema)','Daily moisturization; trigger avoidance','Wet wraps during flares; short, lukewarm baths','Fragrance-free products; cotton clothing','Seek care for extensive infection or poorly controlled flares'],
    ['Acne Vulgaris','Gentle cleansing; avoid picking','Non-comedogenic moisturizers; spot treatments','Sunscreen with retinoids; consistent routine','Seek care for scarring, nodulocystic acne, or pregnancy planning'],
    ['Cellulitis','Elevate limb; rest','Wound care; keep area clean/dry','Prevent skin breaks; manage athlete’s foot','Seek urgent care for fever, rapid spread, or systemic symptoms'],
    ['Contact Dermatitis','Identify and avoid irritants/allergens','Cool compresses; emollients','Protective equipment at work; barrier creams','Seek care if facial/genital involvement, large areas, or infection']
  ];
  for (const [dName, lifestyle, home, prevention, when] of addRemedies) {
    const did = await idOf('diseases', dName);
    if (did) await run(db, 'INSERT OR IGNORE INTO remedies(disease_id, lifestyle, home_remedies, prevention, when_to_seek_care) VALUES (?,?,?,?,?)', [did, lifestyle, home, prevention, when]);
  }

  console.log('Extra (bone & skin) seed completed.');
}

seedExtra().catch((e) => { console.error('Seed extra error:', e); process.exit(1); });
