PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS demographics (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT UNIQUE NOT NULL CHECK (name IN ('general','men','women','children','elderly'))
);

CREATE TABLE IF NOT EXISTS diseases (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT UNIQUE NOT NULL,
  description TEXT,
  category TEXT
);

CREATE TABLE IF NOT EXISTS symptoms (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT UNIQUE NOT NULL,
  description TEXT
);

CREATE TABLE IF NOT EXISTS disease_symptoms (
  disease_id INTEGER NOT NULL,
  symptom_id INTEGER NOT NULL,
  commonality TEXT,
  PRIMARY KEY (disease_id, symptom_id),
  FOREIGN KEY (disease_id) REFERENCES diseases(id) ON DELETE CASCADE,
  FOREIGN KEY (symptom_id) REFERENCES symptoms(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS treatments (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  disease_id INTEGER NOT NULL,
  title TEXT NOT NULL,
  details TEXT,
  FOREIGN KEY (disease_id) REFERENCES diseases(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS medications (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT UNIQUE NOT NULL,
  generic_name TEXT,
  uses TEXT,
  dosage TEXT,
  side_effects TEXT,
  warnings TEXT
);

CREATE TABLE IF NOT EXISTS medication_diseases (
  medication_id INTEGER NOT NULL,
  disease_id INTEGER NOT NULL,
  PRIMARY KEY (medication_id, disease_id),
  FOREIGN KEY (medication_id) REFERENCES medications(id) ON DELETE CASCADE,
  FOREIGN KEY (disease_id) REFERENCES diseases(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS disease_demographics (
  disease_id INTEGER NOT NULL,
  demographic_id INTEGER NOT NULL,
  notes TEXT,
  PRIMARY KEY (disease_id, demographic_id),
  FOREIGN KEY (disease_id) REFERENCES diseases(id) ON DELETE CASCADE,
  FOREIGN KEY (demographic_id) REFERENCES demographics(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS remedies (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  disease_id INTEGER NOT NULL,
  lifestyle TEXT,
  home_remedies TEXT,
  prevention TEXT,
  when_to_seek_care TEXT,
  FOREIGN KEY (disease_id) REFERENCES diseases(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_diseases_name ON diseases(name);
CREATE INDEX IF NOT EXISTS idx_symptoms_name ON symptoms(name);
CREATE INDEX IF NOT EXISTS idx_medications_name ON medications(name);
