import express from 'express';
import dotenv from 'dotenv';
import OpenAI from 'openai';
import { GoogleGenerativeAI } from '@google/generative-ai';
import { getDb } from '../db/index.js';
import textToSpeech from '@google-cloud/text-to-speech';
import fetch from 'node-fetch';

dotenv.config();

export const router = express.Router();

const openaiKey = process.env.OPENAI_API_KEY;
const openai = openaiKey ? new OpenAI({ apiKey: openaiKey }) : null;
const geminiKey = process.env.GEMINI_API_KEY;
const genAI = geminiKey ? new GoogleGenerativeAI(geminiKey) : null;
// Google Cloud TTS client (optional)
let gttsClient = null;
try {
  if (process.env.GOOGLE_TTS_CREDENTIALS) {
    const creds = JSON.parse(process.env.GOOGLE_TTS_CREDENTIALS);
    gttsClient = new textToSpeech.TextToSpeechClient({ credentials: creds });
  } else {
    // Will use GOOGLE_APPLICATION_CREDENTIALS path if available
    gttsClient = new textToSpeech.TextToSpeechClient();
  }
} catch {
  gttsClient = null;
}

// Utility to format safety notice
function safetyNotice() {
  return 'This information is for educational purposes and is not a substitute for professional medical advice. If symptoms are severe or persistent, seek professional care or emergency services.';
}

// Detect common greeting messages
function isGreeting(message = '') {
  const text = String(message || '').trim().toLowerCase();
  if (!text) return false;
  const greetings = [
    'hi', 'hello', 'hey', 'howdy', 'greetings', 'good morning', 'good afternoon', 'good evening', 'namaste', 'yo', 'sup', 'hola', 'hii'
  ];
  // Simple exact/starts-with match to avoid false positives like 'hiv'
  const normalized = text.replace(/[!.,]/g, '');
  return greetings.some(g => normalized === g || normalized.startsWith(g + ' '));
}

function languageLabel(code = 'en') {
  const map = {
    af: 'Afrikaans',
    sq: 'Shqip (Albanian)',
    am: 'አማርኛ (Amharic)',
    ar: 'العربية (Arabic)',
    hy: 'Հայերեն (Armenian)',
    as: 'অসমীয়া (Assamese)',
    az: 'Azərbaycan dili (Azerbaijani)',
    eu: 'Euskara (Basque)',
    be: 'Беларуская (Belarusian)',
    bn: 'বাংলা (Bengali)',
    bs: 'Bosanski (Bosnian)',
    bg: 'Български (Bulgarian)',
    my: 'မြန်မာ (Burmese)',
    ca: 'Català (Catalan)',
    'zh-CN': '中文(简体) (Chinese Simplified)',
    'zh-TW': '中文(繁體) (Chinese Traditional)',
    hr: 'Hrvatski (Croatian)',
    cs: 'Čeština (Czech)',
    da: 'Dansk (Danish)',
    nl: 'Nederlands (Dutch)',
    en: 'English',
    et: 'Eesti (Estonian)',
    fa: 'فارسی (Persian)',
    fi: 'Suomi (Finnish)',
    fr: 'Français (French)',
    gl: 'Galego (Galician)',
    ka: 'ქართული (Georgian)',
    de: 'Deutsch (German)',
    el: 'Ελληνικά (Greek)',
    gu: 'ગુજરાતી (Gujarati)',
    brx: 'बोड़ो (Bodo)',
    doi: 'डोगरी (Dogri)',
    ha: 'Hausa',
    he: 'עברית (Hebrew)',
    hi: 'हिन्दी (Hindi)',
    hu: 'Magyar (Hungarian)',
    is: 'Íslenska (Icelandic)',
    id: 'Bahasa Indonesia (Indonesian)',
    ga: 'Gaeilge (Irish)',
    it: 'Italiano (Italian)',
    ja: '日本語 (Japanese)',
    kn: 'ಕನ್ನಡ (Kannada)',
    kok: 'कोंकणी (Konkani)',
    ks: 'کٲشُر (Kashmiri)',
    mai: 'मैथिली (Maithili)',
    kk: 'Қазақ тілі (Kazakh)',
    km: 'ភាសាខ្មែរ (Khmer)',
    ko: '한국어 (Korean)',
    ky: 'Кыргызча (Kyrgyz)',
    lo: 'ລາວ (Lao)',
    lv: 'Latviešu (Latvian)',
    lt: 'Lietuvių (Lithuanian)',
    mk: 'Македонски (Macedonian)',
    ms: 'Bahasa Melayu (Malay)',
    ml: 'മലയാളം (Malayalam)',
    mt: 'Malti (Maltese)',
    mr: 'मराठी (Marathi)',
    mni: 'ꯃꯅꯤ ꯄꯥꯛ (Meitei/Manipuri)',
    mn: 'Монгол (Mongolian)',
    ne: 'नेपाली (Nepali)',
    nb: 'Norsk Bokmål (Norwegian)',
    nn: 'Norsk Nynorsk (Norwegian Nynorsk)',
    or: 'ଓଡ଼ିଆ (Odia)',
    ps: 'پښتو (Pashto)',
    pl: 'Polski (Polish)',
    'pt-BR': 'Português (Brasil)',
    'pt-PT': 'Português (Portugal)',
    pa: 'ਪੰਜਾਬੀ (Punjabi)',
    sa: 'संस्कृतम् (Sanskrit)',
    sat: 'ᱥᱟᱱᱛᱟᱲᱤ (Santali)',
    sd: 'سنڌي (Sindhi)',
    ro: 'Română (Romanian)',
    ru: 'Русский (Russian)',
    sr: 'Српски (Serbian)',
    si: 'සිංහල (Sinhala)',
    sk: 'Slovenčina (Slovak)',
    sl: 'Slovenščina (Slovenian)',
    so: 'Soomaali (Somali)',
    'es-ES': 'Español (España)',
    'es-MX': 'Español (México)',
    sw: 'Kiswahili (Swahili)',
    sv: 'Svenska (Swedish)',
    tl: 'Tagalog (Filipino)',
    ta: 'தமிழ் (Tamil)',
    te: 'తెలుగు (Telugu)',
    th: 'ไทย (Thai)',
    tr: 'Türkçe (Turkish)',
    uk: 'Українська (Ukrainian)',
    ur: 'اردو (Urdu)',
    uz: 'Oʻzbekcha (Uzbek)',
    vi: 'Tiếng Việt (Vietnamese)',
    xh: 'isiXhosa (Xhosa)',
    yo: 'Yorùbá (Yoruba)',
    zu: 'isiZulu (Zulu)'
  };
  return map[code] || 'English';
}

// Simple heuristic to detect medical/health/medication related queries
function isMedicalQuery(message = '') {
  const text = String(message || '').toLowerCase();
  if (!text.trim()) return false;
  // Whitelist-based keywords: symptoms, diseases, medications, first aid, body parts, etc.
  const keywords = [
    // general health
    'health', 'healthy', 'wellness', 'clinic', 'hospital', 'doctor', 'nurse', 'first aid', 'emergency', 'ambulance',
    // symptoms
    'fever', 'cough', 'cold', 'pain', 'headache', 'nausea', 'vomit', 'diarrhea', 'rash', 'sore throat', 'fatigue', 'dizziness', 'shortness of breath',
    // conditions/diseases
    'diabetes', 'hypertension', 'asthma', 'covid', 'flu', 'stroke', 'heart attack', 'fracture', 'allergy', 'anaphylaxis', 'infection', 'cancer',
    // medications
    'tablet', 'tablets', 'pill', 'pills', 'drug', 'drugs', 'medicine', 'medication', 'dosage', 'mg', 'side effects', 'paracetamol', 'ibuprofen',
    // anatomy
    'chest', 'abdomen', 'stomach', 'back', 'neck', 'arm', 'leg', 'knee', 'hip', 'lung', 'heart', 'brain', 'kidney', 'liver', 'skin', 'eye', 'ear', 'nose', 'throat',
    // prevention & care
    'vaccine', 'vaccination', 'diet', 'exercise', 'therapy', 'rehab', 'physiotherapy', 'wound', 'burn', 'bleeding',
  ];
  return keywords.some(k => text.includes(k));
}

// Remedies and prevention for a disease
router.get('/remedies/:disease', async (req, res) => {
  const dName = req.params.disease;
  const { db, get, all } = getDb();
  try {
    const disease = await get(db, 'SELECT * FROM diseases WHERE name = ?', [dName]);
    if (!disease) return res.status(404).json({ error: 'Disease not found' });
    const rem = await get(db, 'SELECT * FROM remedies WHERE disease_id = ?', [disease.id]);
    const treatments = await all(db, 'SELECT * FROM treatments WHERE disease_id = ?', [disease.id]);
    res.json({ disease, remedies: rem || null, treatments, notice: safetyNotice() });
  } catch (e) {
    res.status(500).json({ error: 'Remedies lookup failed', details: e.message });
  }
});

// Women’s Health endpoint (focused answers for women's problems)
router.post('/womens-health', async (req, res) => {
  const { query = '', language = 'en', history = [] } = req.body || {};
  if (!query) return res.status(400).json({ error: 'query is required' });
  const { db, all } = getDb();

  try {
    // Pull context emphasizing female-focused conditions, symptoms, medications
    const context = await all(db, `
      SELECT 'disease' as type, name, description as text FROM diseases 
        WHERE name LIKE ? OR description LIKE ? OR category LIKE 'Obstetrics' OR category LIKE 'Gyne%'
      UNION ALL
      SELECT 'symptom' as type, name, description as text FROM symptoms WHERE name LIKE ?
      UNION ALL
      SELECT 'medication' as type, name, uses as text FROM medications WHERE name LIKE ? OR uses LIKE ?
      LIMIT 25
    `, [
      `%${query}%`, `%${query}%`,
      `%${query}%`,
      `%${query}%`, `%${query}%`
    ]);

    const safety = 'Caution: This is educational information, not a diagnosis. If you have severe pain, heavy bleeding, fainting, chest pain, severe breathlessness, or neurologic symptoms, seek emergency care. Otherwise, consult a clinician for personalized advice.';
    const historyText = Array.isArray(history) && history.length
      ? ('Conversation so far (women\'s health):\n' + history.map(h => `${h.role === 'assistant' ? 'Assistant' : 'User'}: ${String(h.content||'').slice(0, 500)}`).join('\n') + '\n')
      : '';
    const structuredGuide = `Provide a short, accurate answer in ${languageLabel(language)} (code ${language}). Focus on women's health (gynecology, pregnancy, periods, PCOS, pelvic pain, menopause, breastfeeding, contraception). Keep it structured: \n- Likely causes (most likely first)\n- What to do now (self-care)\n- OTC options (generic names, typical adult doses; warn to read labels and check contraindications)\n- When to see a doctor / red flags\nBe concise. Include a caution.`;

    let answer = '';
    if (genAI) {
      const prompt = `You are a safe, helpful women\'s health assistant. ${structuredGuide}\n${historyText}Context (DB snippets):\n${JSON.stringify(context, null, 2)}\nUser question: ${query}\n${safety}\nAnswer:`;
      const model = genAI.getGenerativeModel({ model: 'gemini-1.5-flash' });
      const result = await model.generateContent({ contents: [{ role: 'user', parts: [{ text: prompt }] }] });
      const text = result?.response?.text?.();
      answer = text || '';
    } else if (openai) {
      const prompt = `You are a safe, helpful women\'s health assistant. ${structuredGuide}\n${historyText}Context (DB snippets):\n${JSON.stringify(context, null, 2)}\nUser question: ${query}\n${safety}\nAnswer:`;
      const completion = await openai.chat.completions.create({
        model: 'gpt-4o-mini',
        messages: [
          { role: 'system', content: 'You provide women\'s health information (gynecology, pregnancy, contraception, PCOS, periods, pelvic pain, menopause, breastfeeding). Be concise, structured, include a caution.' },
          { role: 'user', content: prompt }
        ],
        temperature: 0.2
      });
      answer = completion.choices?.[0]?.message?.content || '';
    } else {
      // Deterministic fallback: concise sections, language-aware headings (basic Telugu support)
      const byType = context.reduce((acc, c) => { (acc[c.type] ||= []).push(c); return acc; }, {});
      const causes = (byType.disease || []).slice(0, 5).map(d => d.name);
      const meds = (byType.medication || []).slice(0, 4).map(m => m.name);
      if (language === 'te') {
        const teCaution = 'జాగ్రత్త: ఇది విద్యాపరమైన సమాచారం మాత్రమే. లక్షణాలు తీవ్రమైపోతే లేదా రక్తస్రావం/తీవ్ర నొప్పి ఉంటే వెంటనే వైద్యులను సంప్రదించండి.';
        answer =
`సాధ్యమైన కారణాలు: ${causes.length ? causes.join(', ') : 'సందర్భం నుండి సరిపడ సమాచారం లేదు.'}
ఇప్పుడు మీరు చేయవచ్చు: విశ్రాంతి, ద్రవాలు, నొప్పి నియంత్రణ; తీవ్రమైతే వైద్య సలహా తీసుకోండి.
ఓటిసి ఎంపికలు: ${meds.length ? meds.join(', ') : 'నొప్పికి పారాసెటమాల్ (లేబుల్‌ను పాటించండి)'}; గర్భధారణ/స్తన్యపానంలో వాడకముందు వైద్య సలహా.
ఎప్పుడు డాక్టర్‌ని సంప్రదించాలి: భారీ రక్తస్రావం, తీవ్రమైన పొట్ట/పెల్విక్ నొప్పి, జ్వరం, తలనిర్బంధం, గర్భధారణకు సంబంధించిన ఆందోళనలు.
${teCaution}`;
      } else {
        answer =
`Likely causes: ${causes.length ? causes.join(', ') : 'Not enough local context.'}
What you can do now: rest, fluids, pain control; if severe or worsening, seek care.
OTC options: ${meds.length ? meds.join(', ') : 'paracetamol/acetaminophen for pain (follow label)'}; if pregnant/breastfeeding, ask clinician first.
When to see a doctor: heavy bleeding, severe pelvic/abdominal pain, fever, fainting, pregnancy concerns.
${safety}`;
      }
    }

    res.json({ answer, notice: safetyNotice() });
  } catch (e) {
    res.status(500).json({ error: 'Women\'s health query failed', details: e.message });
  }
});

// Nearby hospitals using OpenStreetMap Overpass API
router.get('/nearby-hospitals', async (req, res) => {
  const lat = parseFloat(req.query.lat);
  const lon = parseFloat(req.query.lon);
  const radius = Math.min(parseInt(req.query.radius || '3000', 10) || 3000, 100000); // cap at 100km
  const query = String(req.query.q || '').trim().toLowerCase();
  if (!isFinite(lat) || !isFinite(lon)) {
    return res.status(400).json({ error: 'lat and lon are required as numbers' });
  }
  // Overpass QL query: hospitals and clinics around the point
  const overpass = `[
    out:json
  ];
  (
    node["amenity"="hospital"](around:${radius},${lat},${lon});
    way["amenity"="hospital"](around:${radius},${lat},${lon});
    relation["amenity"="hospital"](around:${radius},${lat},${lon});
    node["healthcare"="hospital"](around:${radius},${lat},${lon});
    way["healthcare"="hospital"](around:${radius},${lat},${lon});
    relation["healthcare"="hospital"](around:${radius},${lat},${lon});
    node["amenity"="clinic"](around:${radius},${lat},${lon});
    way["amenity"="clinic"](around:${radius},${lat},${lon});
    relation["amenity"="clinic"](around:${radius},${lat},${lon});
  );
  out center 100;`;

  try {
    const resp = await fetch('https://overpass-api.de/api/interpreter', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({ data: overpass })
    });
    if (!resp.ok) {
      const text = await resp.text();
      return res.status(502).json({ error: 'Overpass error', details: text.slice(0, 500) });
    }
    const json = await resp.json();
    const elements = Array.isArray(json?.elements) ? json.elements : [];
    // Map user issue to medical specialties keywords
    function mapIssueToSpecialties(issue = '') {
      const q = String(issue || '').toLowerCase();
      if (!q) return [];
      const map = [
        { keys: ['heart attack', 'chest pain', 'hypertension', 'cardiac', 'cardio', 'mi'], spec: ['cardiology', 'emergency'] },
        { keys: ['stroke', 'seizure', 'epilepsy', 'headache', 'migraine', 'paralysis', 'brain'], spec: ['neurology', 'neurosurgery', 'emergency'] },
        { keys: ['asthma', 'copd', 'breath', 'shortness of breath', 'pneumonia', 'lung'], spec: ['pulmonology', 'respiratory', 'emergency'] },
        { keys: ['diabetes', 'thyroid', 'hormone', 'endocrine'], spec: ['endocrinology'] },
        { keys: ['cancer', 'tumor', 'oncology', 'chemotherapy', 'radiation'], spec: ['oncology', 'radiotherapy'] },
        { keys: ['fracture', 'bone', 'joint', 'orthopedic', 'spine', 'sports injury'], spec: ['orthopedics', 'trauma', 'emergency'] },
        { keys: ['rash', 'skin', 'dermatitis', 'acne'], spec: ['dermatology'] },
        { keys: ['stomach', 'abdomen', 'abdominal pain', 'diarrhea', 'vomit', 'ulcer', 'liver', 'pancreas'], spec: ['gastroenterology', 'hepatology'] },
        { keys: ['kidney', 'renal', 'dialysis'], spec: ['nephrology'] },
        { keys: ['urine', 'prostate', 'stone', 'urolithiasis', 'urology'], spec: ['urology'] },
        { keys: ['eye', 'vision', 'cataract', 'glaucoma'], spec: ['ophthalmology'] },
        { keys: ['ear', 'nose', 'throat', 'sinus', 'tonsil'], spec: ['otolaryngology', 'ent'] },
        { keys: ['pregnancy', 'preeclampsia', 'pcos', 'period', 'gyne', 'gyn', 'obstetric'], spec: ['gynecology', 'obstetrics'] },
        { keys: ['child', 'children', 'pediatric', 'newborn', 'neonatal'], spec: ['pediatrics', 'neonatology'] },
        { keys: ['anaphylaxis', 'allergy', 'immunology'], spec: ['allergy', 'immunology', 'emergency'] },
        { keys: ['mental', 'anxiety', 'depression', 'psychiatry', 'psych'], spec: ['psychiatry', 'psychology'] },
        { keys: ['dent', 'tooth', 'oral'], spec: ['dentistry'] },
        { keys: ['burn'], spec: ['burn unit', 'plastic surgery', 'emergency'] },
      ];
      const out = new Set();
      map.forEach(({ keys, spec }) => { if (keys.some(k => q.includes(k))) spec.forEach(s => out.add(s)); });
      return Array.from(out);
    }

    function extractTagsSpecialties(tags = {}, name = '') {
      const out = new Set();
      const candidates = [];
      if (tags['healthcare:speciality']) candidates.push(tags['healthcare:speciality']);
      if (tags['healthcare:specialty']) candidates.push(tags['healthcare:specialty']);
      if (tags['speciality']) candidates.push(tags['speciality']);
      if (tags['specialty']) candidates.push(tags['specialty']);
      if (tags['department']) candidates.push(tags['department']);
      candidates.join(';').split(/[;,/]/).map(s => s.trim().toLowerCase()).filter(Boolean).forEach(s => out.add(s));
      const n = String(name || '').toLowerCase();
      if (/heart|cardio/.test(n)) out.add('cardiology');
      if (/neuro|brain|stroke/.test(n)) out.add('neurology');
      if (/ortho|bone|spine/.test(n)) out.add('orthopedics');
      if (/eye|vision|ophthalm/.test(n)) out.add('ophthalmology');
      if (/(ent|ear|nose|throat)/.test(n)) out.add('ent');
      if (/cancer|oncolog/.test(n)) out.add('oncology');
      if (/women|gyne|obstet|mother/.test(n)) { out.add('gynecology'); out.add('obstetrics'); }
      if (/child|pediatric|kids/.test(n)) out.add('pediatrics');
      if (/derma|skin/.test(n)) out.add('dermatology');
      if (/urolog/.test(n)) out.add('urology');
      if (/nephro|kidney/.test(n)) out.add('nephrology');
      if (/gastro|stomach|liver|hepat/.test(n)) { out.add('gastroenterology'); out.add('hepatology'); }
      if (/pulmo|respir|lung/.test(n)) out.add('pulmonology');
      if (/psych|mental/.test(n)) out.add('psychiatry');
      if (/emergen/.test(n)) out.add('emergency');
      return Array.from(out);
    }

    const desiredSpecs = mapIssueToSpecialties(query);

    const hospitals = elements.map((el) => {
      const tags = el.tags || {};
      const name = tags.name || null;
      const latLon = el.type === 'node' ? { lat: el.lat, lon: el.lon } : (el.center || {});
      const address = [tags['addr:housenumber'], tags['addr:street'], tags['addr:city'], tags['addr:state'], tags['addr:postcode']]
        .filter(Boolean).join(', ');
      const specialties = extractTagsSpecialties(tags, name);
      // simple matching score
      let matchScore = 0;
      if (desiredSpecs.length) {
        const lowerName = String(name || '').toLowerCase();
        const nameMatch = desiredSpecs.some(s => lowerName.includes(s));
        const specMatchCount = specialties.filter(s => desiredSpecs.includes(s)).length;
        matchScore = (nameMatch ? 2 : 0) + specMatchCount; // name match weights higher
        // also consider emergency for acute issues
        if (desiredSpecs.includes('emergency') && (tags.emergency === 'yes' || specialties.includes('emergency'))) {
          matchScore += 1;
        }
      }
      return {
        id: `${el.type}/${el.id}`,
        name,
        lat: latLon.lat,
        lon: latLon.lon,
        address: address || null,
        phone: tags.phone || tags['contact:phone'] || null,
        website: tags.website || tags['contact:website'] || null,
        specialties,
        matchScore
      };
    }).filter(h => isFinite(h.lat) && isFinite(h.lon))
      .reduce((acc, h) => { // de-duplicate by name+coords
        const key = `${h.name || 'unknown'}:${h.lat.toFixed(5)},${h.lon.toFixed(5)}`;
        if (!acc.map.has(key)) { acc.map.set(key, true); acc.list.push(h); }
        return acc;
      }, { map: new Map(), list: [] }).list;

    let filtered = hospitals;
    if (query && desiredSpecs.length) {
      // keep items with positive score first, then the rest
      const positive = hospitals.filter(h => h.matchScore > 0);
      const others = hospitals.filter(h => h.matchScore === 0);
      filtered = [...positive, ...others];
    }

    // Return top 20 by relevance (matchScore desc) then by name
    const top = filtered
      .sort((a, b) => (b.matchScore - a.matchScore) || ((a.name || '').localeCompare(b.name || '')))
      .slice(0, 20);

    res.json({ hospitals: top, query, desiredSpecialties: desiredSpecs });
  } catch (e) {
    res.status(500).json({ error: 'Failed to query hospitals', details: e.message });
  }
});

// Chat endpoint with optional OpenAI
router.post('/chat', async (req, res) => {
  const { message = '', demographic = 'general', language = 'en', history = [] } = req.body || {};
  if (!message) return res.status(400).json({ error: 'Message is required' });
  const { db, all } = getDb();

  // Friendly greeting path (allowed regardless of medical scope)
  if (isGreeting(message)) {
    return res.json({
      answer: 'Hello! I am your medical assistant. Please ask a health or medication question so I can help.',
      notice: safetyNotice()
    });
  }

  try {
    // Simple retrieval over DB for context
    const context = await all(db, `
      SELECT 'disease' as type, name, description as text FROM diseases WHERE name LIKE ? OR description LIKE ?
      UNION ALL
      SELECT 'symptom' as type, name, description as text FROM symptoms WHERE name LIKE ?
      UNION ALL
      SELECT 'medication' as type, name, uses as text FROM medications WHERE name LIKE ? OR uses LIKE ?
      LIMIT 20
    `, [
      `%${message}%`, `%${message}%`,
      `%${message}%`,
      `%${message}%`, `%${message}%`
    ]);

    // Scope restriction: only answer medical/health/medication topics.
    // If the message does not look medical, return a concise refusal regardless of DB hits.
    if (!isMedicalQuery(message)) {
      return res.json({
        answer: 'I only answer medical and health-related questions (symptoms, conditions, medications, first aid). Please ask a medical question.',
        notice: safetyNotice()
      });
    }

    // Compose a concise, structured instruction for models
    const safety = 'Caution: Information provided is for education, not a diagnosis. If symptoms are severe, worsening, or you have red flags (chest pain, severe breathlessness, weakness on one side, confusion, uncontrolled bleeding), seek emergency care. Otherwise, consult a clinician for personalized advice.';
    const historyText = Array.isArray(history) && history.length
      ? ('Conversation so far:\n' + history.map(h => `${h.role === 'assistant' ? 'Assistant' : 'User'}: ${String(h.content||'').slice(0, 500)}`).join('\n') + '\n')
      : '';
    const structuredGuide = `Provide a short, accurate answer in ${languageLabel(language)} (code ${language}). Keep it concise and structured with these sections when relevant: \n- Possible causes (most likely first)\n- What you can do now (self-care)\n- Over-the-counter medicines (generic names, typical adult doses, max daily dose; warn to read labels and check allergies/contraindications)\n- When to see a doctor / red flags\nEnd with a one-line caution. Avoid certainty; provide ranges and options. Adapt for demographic: ${demographic}. Use the database context if useful. Avoid unnecessary content.`;
    let answer = '';
    if (genAI) {
      const prompt = `You are a safe, helpful medical assistant. ${structuredGuide}\n${historyText}Context (DB snippets):\n${JSON.stringify(context, null, 2)}\nUser message: ${message}\n${safety}\nAnswer:`;
      const model = genAI.getGenerativeModel({ model: 'gemini-1.5-flash' });
      const result = await model.generateContent({ contents: [{ role: 'user', parts: [{ text: prompt }] }] });
      const text = result?.response?.text?.();
      answer = text || '';
    } else if (openai) {
      const prompt = `You are a safe, helpful medical assistant. ${structuredGuide}\n${historyText}Context (DB snippets):\n${JSON.stringify(context, null, 2)}\nUser message: ${message}\n${safety}\nAnswer:`;
      const completion = await openai.chat.completions.create({
        model: 'gpt-4o-mini',
        messages: [
          { role: 'system', content: 'You provide medical information only. If a user asks about non-medical topics, concisely refuse and ask for a medical/health/medication question. Be concise. Always include a caution. Never be certain of a diagnosis; offer likely possibilities and standard self-care steps and OTC options with typical adult doses where appropriate. Consider demographic. Use prior conversation for context.' },
          { role: 'user', content: prompt }
        ],
        temperature: 0.2
      });
      answer = completion.choices?.[0]?.message?.content || '';
    } else {
      // Fallback: summarize context deterministically
      const byType = context.reduce((acc, c) => { (acc[c.type] ||= []).push(c); return acc; }, {});
      const causes = (byType.disease || []).slice(0, 5).map(d => d.name);
      const symps = (byType.symptom || []).slice(0, 8).map(s => s.name);
      const meds = (byType.medication || []).slice(0, 4).map(m => m.name);
      if (language === 'te') {
        // Simple Telugu headings and caution; content names remain as-is from DB
        const teCaution = 'జాగ్రత్త: ఇది విద్యాపరమైన సమాచారం మాత్రమే. లక్షణాలు తీవ్రంగా ఉంటే లేదా పెరుగుతూ ఉంటే, అత్యవసర వైద్య సహాయం పొందండి.';
        answer =
`సాధ్యమైన కారణాలు: ${causes.length ? causes.join(', ') : 'స్థానిక సందర్భం నుండి సరిపడ సమాచారం లేదు.'}
ఇప్పుడు మీరు చేయవచ్చు: విశ్రాంతి, నీరు ఎక్కువగా తాగండి, సమతుల్య ఆహారం; ట్రిగ్గర్స్ నివారించండి; లక్షణాలను గమనించండి.
ఓవర్-ద-కౌంటర్ ఎంపికలు: ${meds.length ? meds.join(', ') : 'జ్వరము/నొప్పికి పారాసెటమాల్ (లేబుల్ సూచనలను పాటించండి)'} (లేబుల్ చదవండి; అలెర్జీలు/విరుద్ధ సూచనలు ఉన్నాయా చూడండి).
ఎప్పుడు డాక్టర్‌ని సంప్రదించాలి: 3 రోజులకు మించి ఉన్న అధిక జ్వరం, తీవ్రమైన/పెరుగుతున్న నొప్పి, శ్వాసలో ఇబ్బంది, డీహైడ్రేషన్, లేదా ఏదైనా రెడ్ ఫ్లాగ్స్.
${teCaution}`;
      } else {
        answer = `${message ? '' : ''}` +
`Possible causes: ${causes.length ? causes.join(', ') : 'Not enough data from local context.'}
What you can do now: rest, fluids, balanced diet; avoid triggers; monitor symptoms.
Over-the-counter options: ${meds.length ? meds.join(', ') : 'paracetamol/acetaminophen for fever/pain as per label'} (read labels; check allergies/contraindications).
When to see a doctor: high fever >3 days, severe/worsening pain, breathing trouble, dehydration, or any red flags.
${safety}`;
      }
    }

    res.json({ answer, notice: safetyNotice() });
  } catch (e) {
    res.status(500).json({ error: 'Chat failed', details: e.message });
  }
});

// Cloud Text-to-Speech endpoint (returns base64 MP3)
router.post('/tts', async (req, res) => {
  try {
    if (!gttsClient) return res.status(503).json({ error: 'Google TTS not configured' });
    const text = String(req.body?.text || '').trim();
    const lang = String(req.body?.language || 'en');
    if (!text) return res.status(400).json({ error: 'text is required' });
    const langMap = {
      te: 'te-IN',
      hi: 'hi-IN',
      ta: 'ta-IN',
      kn: 'kn-IN',
      ml: 'ml-IN',
      mr: 'mr-IN',
      gu: 'gu-IN',
      bn: 'bn-IN',
      en: 'en-US',
    };
    const languageCode = langMap[lang] || 'en-US';
    // Choose a specific voice for Telugu to avoid falling back to English
    const voiceNameMap = {
      'te-IN': 'te-IN-Standard-A',
      'hi-IN': 'hi-IN-Standard-A',
      'ta-IN': 'ta-IN-Standard-A',
      'kn-IN': 'kn-IN-Standard-A',
      'ml-IN': 'ml-IN-Standard-A',
      'mr-IN': 'mr-IN-Standard-A',
      'gu-IN': 'gu-IN-Standard-A',
      'bn-IN': 'bn-IN-Standard-A',
      'en-US': 'en-US-Standard-C'
    };
    const voice = { languageCode, ssmlGender: 'FEMALE' };
    if (voiceNameMap[languageCode]) voice.name = voiceNameMap[languageCode];
    const request = {
      input: { text },
      voice,
      audioConfig: { audioEncoding: 'MP3' },
    };
    const [response] = await gttsClient.synthesizeSpeech(request);
    const audioBase64 = response.audioContent?.toString('base64');
    if (!audioBase64) return res.status(500).json({ error: 'TTS failed' });
    res.json({ audio: `data:audio/mp3;base64,${audioBase64}` });
  } catch (e) {
    res.status(500).json({ error: 'TTS error', details: e.message });
  }
});

 // Medication details endpoint
 router.get('/medications/:name', async (req, res) => {
   const name = String(req.params.name || '').trim();
   const { db, get, all } = getDb();
   if (!name) return res.status(400).json({ error: 'name is required' });
   try {
     // Try exact match first, then fallback to LIKE
     let med = await get(db, 'SELECT * FROM medications WHERE name = ?', [name]);
     if (!med) {
       med = await get(db, 'SELECT * FROM medications WHERE name LIKE ? COLLATE NOCASE', [name + '%']);
     }
     if (!med) {
       return res.json({
         medication: null,
         relatedDiseases: [],
         message: 'No exact medication match found. Try a generic name or partial spelling.',
         notice: safetyNotice()
       });
     }
     const related = await all(db, `
       SELECT d.* FROM diseases d
       JOIN medication_diseases md ON md.disease_id = d.id
       WHERE md.medication_id = ?
       ORDER BY d.name
     `, [med.id]);
     res.json({ medication: med, relatedDiseases: related, notice: safetyNotice() });
   } catch (e) {
     res.status(500).json({ error: 'Medication lookup failed', details: e.message });
   }
 });

 // Unified medical search across diseases, symptoms, medications
 router.get('/search', async (req, res) => {
   const q = String(req.query.q || '').trim();
   const demographic = String(req.query.demographic || 'general');
   const { db, all, get } = getDb();
   if (!q) return res.status(400).json({ error: 'q is required' });
   try {
     const rows = await all(db, `
       SELECT 'disease' AS type, d.name, d.description AS text, d.category, d.id AS id FROM diseases d
         WHERE d.name LIKE ? OR d.description LIKE ? OR d.category LIKE ?
       UNION ALL
       SELECT 'symptom' AS type, s.name, s.description AS text, NULL AS category, s.id AS id FROM symptoms s
         WHERE s.name LIKE ? OR s.description LIKE ?
       UNION ALL
       SELECT 'medication' AS type, m.name, m.uses AS text, NULL AS category, m.id AS id FROM medications m
         WHERE m.name LIKE ? OR m.generic_name LIKE ? OR m.uses LIKE ?
       LIMIT 50
     `, [
       `%${q}%`, `%${q}%`, `%${q}%`,
       `%${q}%`, `%${q}%`,
       `%${q}%`, `%${q}%`, `%${q}%`
     ]);

     const demoRow = await get(db, 'SELECT id FROM demographics WHERE name = ?', [demographic]);
     const demoId = demoRow?.id || null;
     let demoNotes = {};
     if (demoId) {
       const notes = await all(db, 'SELECT disease_id, notes FROM disease_demographics WHERE demographic_id = ?', [demoId]);
       demoNotes = Object.fromEntries(notes.map(n => [String(n.disease_id), n.notes]));
     }

     const results = rows.map(r => {
       const out = { ...r };
       if (r.type === 'disease') {
         const key = String(r.id);
         if (demoNotes[key]) out.demographic_notes = demoNotes[key];
       }
       return out;
     });

     res.json({ query: q, demographic, results, notice: safetyNotice() });
   } catch (e) {
     res.status(500).json({ error: 'Search failed', details: e.message });
   }
 });

 // Symptom checker: rank diseases by overlap with provided symptoms
 router.post('/symptoms/check', async (req, res) => {
   const body = req.body || {};
   const demographic = String(body.demographic || 'general');
   const symptomsIn = Array.isArray(body.symptoms) ? body.symptoms : [];
   if (!symptomsIn.length) return res.status(400).json({ error: 'symptoms array is required' });
   const { db, all, get } = getDb();
   try {
     const norm = symptomsIn.map(s => String(s || '').trim()).filter(Boolean);
     if (!norm.length) return res.status(400).json({ error: 'symptoms array is empty after normalization' });

     const symRows = await all(db, `SELECT id, name FROM symptoms WHERE ${norm.map(() => 'name LIKE ?').join(' OR ')}`,
       norm.map(s => `%${s}%`)
     );
     const symIds = symRows.map(r => r.id);
     if (!symIds.length) {
       return res.json({
         matches: [],
         message: 'No matching symptoms found in the local database. Try broader terms (e.g., "fever", "cough").',
         notice: safetyNotice()
       });
     }

     const disRows = await all(db, `
       SELECT d.id, d.name, d.description, d.category,
              SUM(CASE ds.commonality WHEN 'common' THEN 2 WHEN 'occasional' THEN 1 ELSE 1 END) AS score,
              COUNT(*) AS match_count
       FROM disease_symptoms ds
       JOIN diseases d ON d.id = ds.disease_id
       WHERE ds.symptom_id IN (${symIds.map(() => '?').join(',')})
       GROUP BY d.id
       ORDER BY score DESC, match_count DESC, d.name ASC
       LIMIT 20
     `, symIds);

     const matches = [];
     for (const d of disRows) {
       const ms = await all(db, `
         SELECT s.name, ds.commonality FROM disease_symptoms ds
         JOIN symptoms s ON s.id = ds.symptom_id
         WHERE ds.disease_id = ? AND ds.symptom_id IN (${symIds.map(() => '?').join(',')})
       `, [d.id, ...symIds]);
       matches.push({
         disease: { id: d.id, name: d.name, description: d.description, category: d.category },
         matchedSymptoms: ms,
         score: d.score,
         matchCount: d.match_count
       });
     }

     const demoRow2 = await get(db, 'SELECT id FROM demographics WHERE name = ?', [demographic]);
     const demoId2 = demoRow2?.id || null;
     let notesMap = {};
     if (demoId2) {
       const notes = await all(db, 'SELECT disease_id, notes FROM disease_demographics WHERE demographic_id = ?', [demoId2]);
       notesMap = Object.fromEntries(notes.map(n => [String(n.disease_id), n.notes]));
     }
     const ranked = matches.map(m => ({
       ...m,
       demographic_notes: notesMap[String(m.disease.id)] || null
     }));

     res.json({
       demographic,
       inputSymptoms: norm,
       results: ranked,
       advice: 'These are informational possibilities only. Seek emergency care for red flags (severe chest pain, trouble breathing, confusion, one-sided weakness, uncontrolled bleeding).',
       notice: safetyNotice()
     });
   } catch (e) {
     res.status(500).json({ error: 'Symptom check failed', details: e.message });
   }
 });
 // Medication details endpoint
 router.get('/medications/:name', async (req, res) => {
   const name = String(req.params.name || '').trim();
   const { db, get, all } = getDb();
   if (!name) return res.status(400).json({ error: 'name is required' });
   try {
     // Try exact match first, then fallback to LIKE
     let med = await get(db, 'SELECT * FROM medications WHERE name = ?', [name]);
     if (!med) {
       med = await get(db, 'SELECT * FROM medications WHERE name LIKE ? COLLATE NOCASE', [name + '%']);
     }
     if (!med) {
       return res.json({
         medication: null,
         relatedDiseases: [],
         message: 'No exact medication match found. Try a generic name or partial spelling.',
         notice: safetyNotice()
       });
     }
     const related = await all(db, `
       SELECT d.* FROM diseases d
       JOIN medication_diseases md ON md.disease_id = d.id
       WHERE md.medication_id = ?
       ORDER BY d.name
     `, [med.id]);
     res.json({ medication: med, relatedDiseases: related, notice: safetyNotice() });
   } catch (e) {
     res.status(500).json({ error: 'Medication lookup failed', details: e.message });
   }
 });

 // Unified medical search across diseases, symptoms, medications
 router.get('/search', async (req, res) => {
   const q = String(req.query.q || '').trim();
   const demographic = String(req.query.demographic || 'general');
   const { db, all, get } = getDb();
   if (!q) return res.status(400).json({ error: 'q is required' });
   try {
     const rows = await all(db, `
       SELECT 'disease' AS type, d.name, d.description AS text, d.category, d.id AS id FROM diseases d
         WHERE d.name LIKE ? OR d.description LIKE ? OR d.category LIKE ?
       UNION ALL
       SELECT 'symptom' AS type, s.name, s.description AS text, NULL AS category, s.id AS id FROM symptoms s
         WHERE s.name LIKE ? OR s.description LIKE ?
       UNION ALL
       SELECT 'medication' AS type, m.name, m.uses AS text, NULL AS category, m.id AS id FROM medications m
         WHERE m.name LIKE ? OR m.generic_name LIKE ? OR m.uses LIKE ?
       LIMIT 50
     `, [
       `%${q}%`, `%${q}%`, `%${q}%`,
       `%${q}%`, `%${q}%`,
       `%${q}%`, `%${q}%`, `%${q}%`
     ]);

     const demoRow = await get(db, 'SELECT id FROM demographics WHERE name = ?', [demographic]);
     const demoId = demoRow?.id || null;
     let demoNotes = {};
     if (demoId) {
       const notes = await all(db, 'SELECT disease_id, notes FROM disease_demographics WHERE demographic_id = ?', [demoId]);
       demoNotes = Object.fromEntries(notes.map(n => [String(n.disease_id), n.notes]));
     }

     const results = rows.map(r => {
       const out = { ...r };
       if (r.type === 'disease') {
         const key = String(r.id);
         if (demoNotes[key]) out.demographic_notes = demoNotes[key];
       }
       return out;
     });

     res.json({ query: q, demographic, results, notice: safetyNotice() });
   } catch (e) {
     res.status(500).json({ error: 'Search failed', details: e.message });
   }
 });

 // Symptom checker: rank diseases by overlap with provided symptoms
 router.post('/symptoms/check', async (req, res) => {
   const body = req.body || {};
   const demographic = String(body.demographic || 'general');
   const symptomsIn = Array.isArray(body.symptoms) ? body.symptoms : [];
   if (!symptomsIn.length) return res.status(400).json({ error: 'symptoms array is required' });
   const { db, all, get } = getDb();
   try {
     const norm = symptomsIn.map(s => String(s || '').trim()).filter(Boolean);
     if (!norm.length) return res.status(400).json({ error: 'symptoms array is empty after normalization' });

     const symRows = await all(db, `SELECT id, name FROM symptoms WHERE ${norm.map(() => 'name LIKE ?').join(' OR ')}`,
       norm.map(s => `%${s}%`)
     );
     const symIds = symRows.map(r => r.id);
     if (!symIds.length) {
       return res.json({
         matches: [],
         message: 'No matching symptoms found in the local database. Try broader terms (e.g., "fever", "cough").',
         notice: safetyNotice()
       });
     }

     const disRows = await all(db, `
       SELECT d.id, d.name, d.description, d.category,
              SUM(CASE ds.commonality WHEN 'common' THEN 2 WHEN 'occasional' THEN 1 ELSE 1 END) AS score,
              COUNT(*) AS match_count
       FROM disease_symptoms ds
       JOIN diseases d ON d.id = ds.disease_id
       WHERE ds.symptom_id IN (${symIds.map(() => '?').join(',')})
       GROUP BY d.id
       ORDER BY score DESC, match_count DESC, d.name ASC
       LIMIT 20
     `, symIds);

     const matches = [];
     for (const d of disRows) {
       const ms = await all(db, `
         SELECT s.name, ds.commonality FROM disease_symptoms ds
         JOIN symptoms s ON s.id = ds.symptom_id
         WHERE ds.disease_id = ? AND ds.symptom_id IN (${symIds.map(() => '?').join(',')})
       `, [d.id, ...symIds]);
       matches.push({
         disease: { id: d.id, name: d.name, description: d.description, category: d.category },
         matchedSymptoms: ms,
         score: d.score,
         matchCount: d.match_count
       });
     }

     const demoRow2 = await get(db, 'SELECT id FROM demographics WHERE name = ?', [demographic]);
     const demoId2 = demoRow2?.id || null;
     let notesMap = {};
     if (demoId2) {
       const notes = await all(db, 'SELECT disease_id, notes FROM disease_demographics WHERE demographic_id = ?', [demoId2]);
       notesMap = Object.fromEntries(notes.map(n => [String(n.disease_id), n.notes]));
     }
     const ranked = matches.map(m => ({
       ...m,
       demographic_notes: notesMap[String(m.disease.id)] || null
     }));

     res.json({
       demographic,
       inputSymptoms: norm,
       results: ranked,
       advice: 'These are informational possibilities only. Seek emergency care for red flags (severe chest pain, trouble breathing, confusion, one-sided weakness, uncontrolled bleeding).',
       notice: safetyNotice()
     });
   } catch (e) {
     res.status(500).json({ error: 'Symptom check failed', details: e.message });
   }
 });
// --- Biochemical endpoints and extended search ---
// Chemical details
router.get('/chemicals/:name', async (req, res) => {
  const name = String(req.params.name || '').trim();
  const { db, get } = getDb();
  if (!name) return res.status(400).json({ error: 'name is required' });
  try {
    let row = await get(db, 'SELECT * FROM chemicals WHERE name = ?', [name]);
    if (!row) row = await get(db, 'SELECT * FROM chemicals WHERE name LIKE ? COLLATE NOCASE', [name + '%']);
    if (!row) return res.json({ chemical: null, message: 'No exact chemical match found. Try a partial name.', notice: safetyNotice() });
    res.json({ chemical: row, notice: safetyNotice() });
  } catch (e) {
    res.status(500).json({ error: 'Chemical lookup failed', details: e.message });
  }
});

// Enzyme details
router.get('/enzymes/:name', async (req, res) => {
  const name = String(req.params.name || '').trim();
  const { db, get } = getDb();
  if (!name) return res.status(400).json({ error: 'name is required' });
  try {
    let row = await get(db, 'SELECT * FROM enzymes WHERE name = ?', [name]);
    if (!row) row = await get(db, 'SELECT * FROM enzymes WHERE name LIKE ? COLLATE NOCASE', [name + '%']);
    if (!row) return res.json({ enzyme: null, message: 'No exact enzyme match found. Try a partial name.', notice: safetyNotice() });
    res.json({ enzyme: row, notice: safetyNotice() });
  } catch (e) {
    res.status(500).json({ error: 'Enzyme lookup failed', details: e.message });
  }
});

// Extended search including chemicals and enzymes
router.get('/search-extended', async (req, res) => {
  const q = String(req.query.q || '').trim();
  const demographic = String(req.query.demographic || 'general');
  const { db, all, get } = getDb();
  if (!q) return res.status(400).json({ error: 'q is required' });
  try {
    const rows = await all(db, `
      SELECT 'disease' AS type, d.name, d.description AS text, d.category, d.id AS id FROM diseases d
        WHERE d.name LIKE ? OR d.description LIKE ? OR d.category LIKE ?
      UNION ALL
      SELECT 'symptom' AS type, s.name, s.description AS text, NULL AS category, s.id AS id FROM symptoms s
        WHERE s.name LIKE ? OR s.description LIKE ?
      UNION ALL
      SELECT 'medication' AS type, m.name, m.uses AS text, NULL AS category, m.id AS id FROM medications m
        WHERE m.name LIKE ? OR m.generic_name LIKE ? OR m.uses LIKE ?
      UNION ALL
      SELECT 'chemical' AS type, c.name, c.description AS text, c.role AS category, c.id AS id FROM chemicals c
        WHERE c.name LIKE ? OR c.description LIKE ? OR c.clinical_significance LIKE ?
      UNION ALL
      SELECT 'enzyme' AS type, e.name, e.description AS text, e.function AS category, e.id AS id FROM enzymes e
        WHERE e.name LIKE ? OR e.description LIKE ? OR e.clinical_significance LIKE ?
      LIMIT 80
    `, [
      `%${q}%`, `%${q}%`, `%${q}%`,
      `%${q}%`, `%${q}%`,
      `%${q}%`, `%${q}%`, `%${q}%`,
      `%${q}%`, `%${q}%`, `%${q}%`,
      `%${q}%`, `%${q}%`, `%${q}%`
    ]);

    const demoRow = await get(db, 'SELECT id FROM demographics WHERE name = ?', [demographic]);
    const demoId = demoRow?.id || null;
    let demoNotes = {};
    if (demoId) {
      const notes = await all(db, 'SELECT disease_id, notes FROM disease_demographics WHERE demographic_id = ?', [demoId]);
      demoNotes = Object.fromEntries(notes.map(n => [String(n.disease_id), n.notes]));
    }

    const results = rows.map(r => {
      const out = { ...r };
      if (r.type === 'disease') {
        const key = String(r.id);
        if (demoNotes[key]) out.demographic_notes = demoNotes[key];
      }
      return out;
    });

    res.json({ query: q, demographic, results, notice: safetyNotice() });
  } catch (e) {
    res.status(500).json({ error: 'Extended search failed', details: e.message });
  }
});
// --- General Q&A endpoint: answer any question via AI providers ---
router.post('/ask', async (req, res) => {
  const { question = '', language = 'en', history = [] } = req.body || {};
  const q = String(question || '').trim();
  if (!q) return res.status(400).json({ error: 'question is required' });
  const instruction = `Provide a clear, concise answer in ${languageLabel(language)} (code ${language}). If there are unknowns, state them briefly. Use bullet points or short paragraphs.`;
  try {
    let answer = '';
    if (genAI) {
      const prompt = `${instruction}\n${Array.isArray(history) && history.length ? 'Conversation so far:\n' + history.map(h => `${h.role === 'assistant' ? 'Assistant' : 'User'}: ${String(h.content||'').slice(0,500)}`).join('\n') + '\n' : ''}Question: ${q}\nAnswer:`;
      const model = genAI.getGenerativeModel({ model: 'gemini-1.5-flash' });
      const result = await model.generateContent({ contents: [{ role: 'user', parts: [{ text: prompt }] }] });
      answer = result?.response?.text?.() || '';
    } else if (openai) {
      const messages = [
        { role: 'system', content: 'You are a helpful general-purpose assistant. Be accurate, concise, and structured.' },
        { role: 'user', content: `${instruction}\nQuestion: ${q}\nAnswer:` }
      ];
      const completion = await openai.chat.completions.create({ model: 'gpt-4o-mini', messages, temperature: 0.2 });
      answer = completion.choices?.[0]?.message?.content || '';
    } else {
      // Deterministic fallback: echo guidance
      answer = `Here is a concise response based on available local capabilities.\n\nQuestion: ${q}\n\n- We currently do not have an external AI key configured.\n- Please set GEMINI_API_KEY or OPENAI_API_KEY in your environment for richer answers.`;
    }
    res.json({ answer });
  } catch (e) {
    res.status(500).json({ error: 'Ask failed', details: e.message });
  }
});
// --- Biomedical Q&A: human body (anatomy, physiology, cells, tissues, enzymes, skin, etc.) ---
router.post('/biomedical-chat', async (req, res) => {
  const { question = '', language = 'en', history = [] } = req.body || {};
  const q = String(question || '').trim();
  if (!q) return res.status(400).json({ error: 'question is required' });
  const { db, all } = getDb();
  try {
    // Retrieve context from all biomedical tables
    const ctx = await all(db, `
      SELECT 'disease' as type, name, description as text FROM diseases WHERE name LIKE ? OR description LIKE ? OR category LIKE ?
      UNION ALL
      SELECT 'symptom' as type, name, description as text FROM symptoms WHERE name LIKE ? OR description LIKE ?
      UNION ALL
      SELECT 'medication' as type, name, uses as text FROM medications WHERE name LIKE ? OR generic_name LIKE ? OR uses LIKE ?
      UNION ALL
      SELECT 'chemical' as type, name, description as text FROM chemicals WHERE name LIKE ? OR description LIKE ? OR clinical_significance LIKE ?
      UNION ALL
      SELECT 'enzyme' as type, name, description as text FROM enzymes WHERE name LIKE ? OR description LIKE ? OR clinical_significance LIKE ?
      LIMIT 80
    `, [
      `%${q}%`, `%${q}%`, `%${q}%`,
      `%${q}%`, `%${q}%`,
      `%${q}%`, `%${q}%`, `%${q}%`,
      `%${q}%`, `%${q}%`, `%${q}%`,
      `%${q}%`, `%${q}%`, `%${q}%`
    ]);

    const guide = `Provide an accurate, concise biomedical answer in ${languageLabel(language)} (code ${language}). Focus on human body inside and outside: anatomy, physiology, cells, tissues, enzymes, organs, skin, musculoskeletal, etc. Use short sections and bullet points when helpful. Include a brief caution if medical decisions are implied.`;

    let answer = '';
    if (genAI) {
      const prompt = `${guide}\n${Array.isArray(history) && history.length ? 'Conversation so far:\n' + history.map(h => `${h.role === 'assistant' ? 'Assistant' : 'User'}: ${String(h.content||'').slice(0,500)}`).join('\n') + '\n' : ''}Context (DB snippets):\n${JSON.stringify(ctx, null, 2)}\nQuestion: ${q}\nAnswer:`;
      const model = genAI.getGenerativeModel({ model: 'gemini-1.5-flash' });
      const result = await model.generateContent({ contents: [{ role: 'user', parts: [{ text: prompt }] }] });
      answer = result?.response?.text?.() || '';
    } else if (openai) {
      const messages = [
        { role: 'system', content: 'You are a helpful biomedical assistant. Cover anatomy, physiology, cells, tissues, enzymes, organs, and skin. Be concise and accurate. Use short sections and bullets.' },
        { role: 'user', content: `${guide}\nContext (DB snippets):\n${JSON.stringify(ctx, null, 2)}\nQuestion: ${q}\nAnswer:` }
      ];
      const completion = await openai.chat.completions.create({ model: 'gpt-4o-mini', messages, temperature: 0.2 });
      answer = completion.choices?.[0]?.message?.content || '';
    } else {
      // Deterministic fallback: summarize context by types
      const by = ctx.reduce((a,c)=>{(a[c.type] ||= []).push(c); return a;},{});
      const pick = (arr,n)=> (arr||[]).slice(0,n).map(x=>x.name).join(', ');
      answer = `Summary from local biomedical context:\n- Diseases: ${pick(by.disease,5) || '—'}\n- Symptoms: ${pick(by.symptom,8) || '—'}\n- Medications: ${pick(by.medication,5) || '—'}\n- Chemicals: ${pick(by.chemical,5) || '—'}\n- Enzymes: ${pick(by.enzyme,5) || '—'}\n\nFor deeper answers, set GEMINI_API_KEY or OPENAI_API_KEY.`;
    }

    res.json({ answer, notice: safetyNotice() });
  } catch (e) {
    res.status(500).json({ error: 'Biomedical chat failed', details: e.message });
  }
});
// --- Medical Chat (safe fallback) ---
router.post('/chat-safe', async (req, res) => {
  const { message = '', demographic = 'general', language = 'en', history = [] } = req.body || {};
  if (!message) return res.status(400).json({ answer: 'Please provide a medical question.', notice: safetyNotice() });
  const { db, all } = getDb();
  try {
    // Always try to build context
    let context = [];
    try {
      context = await all(db, `
        SELECT 'disease' as type, name, description as text FROM diseases WHERE name LIKE ? OR description LIKE ?
        UNION ALL
        SELECT 'symptom' as type, name, description as text FROM symptoms WHERE name LIKE ?
        UNION ALL
        SELECT 'medication' as type, name, uses as text FROM medications WHERE name LIKE ? OR uses LIKE ?
        LIMIT 20
      `, [ `%${message}%`, `%${message}%`, `%${message}%`, `%${message}%`, `%${message}%` ]);
    } catch {}

    // If looks non-medical, provide concise redirect but do not error
    if (!isMedicalQuery(message)) {
      return res.json({
        answer: 'I focus on medical and health-related questions (symptoms, conditions, medications, first aid). Please ask a medical question.',
        notice: safetyNotice()
      });
    }

    const safety = 'Caution: Information provided is for education, not a diagnosis. If symptoms are severe or worsening (chest pain, severe breathlessness, one-sided weakness, confusion, uncontrolled bleeding), seek emergency care.';
    const historyText = Array.isArray(history) && history.length
      ? ('Conversation so far:\n' + history.map(h => `${h.role === 'assistant' ? 'Assistant' : 'User'}: ${String(h.content||'').slice(0, 500)}`).join('\n') + '\n')
      : '';
    const structuredGuide = `Provide a short, accurate answer in ${languageLabel(language)} (code ${language}). Keep it concise and structured: Possible causes; What to do now; OTC options (generic names, adult typical doses; warn to read labels/contraindications); When to see a doctor. End with a one-line caution. Adapt to demographic: ${demographic}.`;

    let answer = '';
    // Try Gemini
    try {
      if (!answer && genAI) {
        const prompt = `You are a safe, helpful medical assistant. ${structuredGuide}\n${historyText}Context (DB snippets):\n${JSON.stringify(context, null, 2)}\nUser message: ${message}\n${safety}\nAnswer:`;
        const model = genAI.getGenerativeModel({ model: 'gemini-1.5-flash' });
        const result = await model.generateContent({ contents: [{ role: 'user', parts: [{ text: prompt }] }] });
        const text = result?.response?.text?.();
        if (text) answer = text;
      }
    } catch {}

    // Try OpenAI
    try {
      if (!answer && openai) {
        const prompt = `You are a safe, helpful medical assistant. ${structuredGuide}\n${historyText}Context (DB snippets):\n${JSON.stringify(context, null, 2)}\nUser message: ${message}\n${safety}\nAnswer:`;
        const completion = await openai.chat.completions.create({
          model: 'gpt-4o-mini',
          messages: [
            { role: 'system', content: 'You provide medical information only. Be concise, structured, include a caution. Never be certain of a diagnosis.' },
            { role: 'user', content: prompt }
          ],
          temperature: 0.2
        });
        const text = completion.choices?.[0]?.message?.content;
        if (text) answer = text;
      }
    } catch {}

    // Deterministic fallback using local context
    if (!answer || !String(answer).trim()) {
      const byType = context.reduce((acc, c) => { (acc[c.type] ||= []).push(c); return acc; }, {});
      const causes = (byType.disease || []).slice(0, 5).map(d => d.name);
      const meds = (byType.medication || []).slice(0, 4).map(m => m.name);
      if (language === 'te') {
        const teCaution = 'జగరతత: ఇద వదయపరమన సమచర మతరమ. తవరమత వటన వదయలన సపరదచడ.';
        answer =
`సధయమన కరణల: ${causes.length ? causes.join(', ') : 'సథనక సమచర సరపద'}
ఇపపడ చయవచచ: వశరత, దరవల; లకషణలన గమనచడ.
ఓటస: ${meds.length ? meds.join(', ') : 'పరసటమల (లబల చడడ)'}
${teCaution}`;
      } else {
        answer =
`Possible causes: ${causes.length ? causes.join(', ') : 'Not enough local context.'}
What you can do now: rest, fluids; avoid triggers; monitor symptoms.
OTC options: ${meds.length ? meds.join(', ') : 'paracetamol/acetaminophen as per label'}
Caution: Educational information only; not a diagnosis.`;
      }
    }

    return res.json({ answer, notice: safetyNotice() });
  } catch (e) {
    // Never 500: return a minimal safe fallback
    return res.json({ answer: 'I could not generate a detailed answer now. Please try again or rephrase.', notice: safetyNotice() });
  }
});
