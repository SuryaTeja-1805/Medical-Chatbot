# Medical AI Bot

A comprehensive, voice-enabled Medical AI assistant with a clean, responsive UI. Provides search, symptom checker, medication info, remedies, and demographic-specific insights (men, women, children, elderly). Includes a local SQLite knowledge base and optional AI integration.

## Features

- Voice-enabled chat with speech input and optional speech output
- Search diseases, symptoms, and medications
- Symptom checker with ranked possible conditions and safety advice
- Medication info: uses, dosage, side effects, warnings
- Remedies and prevention tips, with "when to seek care"
- Demographic filter: General, Men, Women, Children, Elderly
- Secure backend with rate limiting and Helmet
- Optional AI integration (Gemini or OpenAI), safe deterministic fallback when no API key

## Tech Stack

- Node.js + Express backend (`src/server.js`)
- SQLite database (`src/db/`), schema + seed script
- Simple SPA frontend served from `public/` (vanilla HTML/CSS/JS)

## Quick Start

1. Install dependencies:
```
npm install
```

2. Configure environment:
- Copy `.env.example` to `.env` and fill values if needed.
- For AI features, set `GEMINI_API_KEY` (preferred) or `OPENAI_API_KEY`. Without these, the app uses a safe fallback.

3. Initialize and seed the database:
```
npm run db:seed
```

4. Run the server (development):
```
npm run dev
```
This starts the app at http://localhost:3000

5. Build/Run (production):
```
npm start
```

## Environment Variables

See `.env.example`:
- `PORT` (default 3000)
- `GEMINI_API_KEY` (optional, preferred)
- `OPENAI_API_KEY` (optional)
- `CORS_ORIGIN` (optional, for future tuning)

## Project Structure

```
medical-chatbot/
├─ package.json
├─ .env.example
├─ README.md
├─ public/
│  ├─ index.html
│  ├─ styles.css
│  └─ app.js
└─ src/
   ├─ server.js
   ├─ routes/
   │  └─ api.js
   └─ db/
      ├─ index.js
      ├─ schema.sql
      └─ seed.js
```

## API Overview

- `GET /api/search?q=...&demographic=general|men|women|children|elderly`
- `POST /api/symptoms/check` with `{ symptoms: string[], demographic: string }`
- `GET /api/medications/:name`
- `GET /api/remedies/:disease`
- `POST /api/chat` with `{ message: string, demographic?: string }`

Responses include a safety notice reminding users this is educational information only.

## Voice Input and Output

- Input: Uses `webkitSpeechRecognition` where supported. Click the mic icon to dictate.
- Output: Enable the "Speak responses" checkbox to use the browser's `speechSynthesis`.

## Data Expansion

- Add more diseases, symptoms, medications to the seed logic in `src/db/seed.js`
- Update schema if needed in `src/db/schema.sql`
- Re-run `npm run db:seed` after changes

## Safety and Disclaimer

This app is for educational purposes and not a substitute for professional medical advice, diagnosis, or treatment. For emergencies, call your local emergency number immediately.
