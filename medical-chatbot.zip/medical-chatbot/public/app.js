const chatLog = document.getElementById('chatLog');
const chatText = document.getElementById('chatText');
const sendBtn = document.getElementById('sendBtn');
const micBtn = document.getElementById('micBtn');
const ttsToggle = document.getElementById('ttsToggle');
const demographicSel = document.getElementById('demographic');
const languageSel = document.getElementById('language');
const languageSearch = document.getElementById('languageSearch');
const themeToggle = document.getElementById('themeToggle');
const themeModeSel = document.getElementById('themeMode');
const ttsVoiceSel = document.getElementById('ttsVoice');
const ttsLanguageSel = document.getElementById('ttsLanguage');
// Slider elements
const slider = document.querySelector('.slider');
const sliderViewport = document.querySelector('.slider-viewport');
const sliderTrack = document.querySelector('.slider-track');
const sliderPrev = document.getElementById('sliderPrev');
const sliderNext = document.getElementById('sliderNext');
const slides = sliderTrack ? Array.from(sliderTrack.querySelectorAll('.slide')) : [];
const findHospitalsBtn = document.getElementById('findHospitalsBtn');
const hospitalResults = document.getElementById('hospitalResults');
const hospitalRadius = document.getElementById('hospitalRadius');
const hospitalQuery = document.getElementById('hospitalQuery');
const userCoordsEl = document.getElementById('userCoords');
// First Aid selectors
const firstAidSearch = document.getElementById('firstAidSearch');
const firstAidBtn = document.getElementById('firstAidBtn');
const firstAidResults = document.getElementById('firstAidResults');

// Starter buttons
const starterAsk = document.getElementById('starterAsk');
const starterSymptoms = document.getElementById('starterSymptoms');
const starterMedicine = document.getElementById('starterMedicine');
const starterPreventive = document.getElementById('starterPreventive');

function prefillAndFocus(text) {
  if (!chatText) return;
  chatText.value = text;
  chatText.focus();
}

// --- UI i18n for starter buttons and placeholder (English + Telugu) ---
const I18N = {
  en: {
    starterAsk: 'Ask a Question',
    starterSymptoms: 'Check Symptoms',
    starterMedicine: 'Learn About a Medicine',
    starterPreventive: 'Get Preventive Health Tips',
    placeholder: 'Type your question here…',
  },
  te: {
    starterAsk: 'ప్రశ్న అడగండి',
    starterSymptoms: 'లవ్షణాలను తనిఖీ చేయండి',
    starterMedicine: 'ఔషధం గురించి తెలుసుకోండి',
    starterPreventive: 'నిరోధవ ఆరోగ్య సూచనలు పొందండి',
    placeholder: 'మీ ప్రశ్నను ఇవ్కస టైప్ చేయండి…',
  },
};

function applyI18n() {
  const lang = (languageSel?.value) || 'en';
  const t = I18N[lang] || I18N.en;
  if (starterAsk) starterAsk.textContent = t.starterAsk;
  if (starterSymptoms) starterSymptoms.textContent = t.starterSymptoms;
  if (starterMedicine) starterMedicine.textContent = t.starterMedicine;
  if (starterPreventive) starterPreventive.textContent = t.starterPreventive;
  if (chatText && t.placeholder) chatText.placeholder = t.placeholder;
}
// Apply on load and when chat language changes
applyI18n();
if (languageSel) languageSel.addEventListener('change', applyI18n);

// --- Expand toggles for Chat log and Women's Health ---
// Chat log: place the toggle at the very bottom of the chat panel (after TTS controls)
if (chatLog) {
  // Default collapsed to save space
  chatLog.classList.add('collapsed');
  // Find TTS container to place the toggle after it
  const ttsContainer = document.querySelector('.chat-panel .tts');
  // Remove any existing toggle placed after chatLog from older versions
  const existingAfterLog = chatLog.nextElementSibling;
  if (existingAfterLog && existingAfterLog.classList && existingAfterLog.classList.contains('expand-toggle')) {
    existingAfterLog.remove();
  }
  let toggle = ttsContainer ? ttsContainer.nextElementSibling : null;
  if (!toggle || !toggle.classList || !toggle.classList.contains('expand-toggle')) {
    toggle = document.createElement('button');
    toggle.className = 'expand-toggle';
    toggle.innerHTML = '<span class="arrow">▼</span> Show more';
    if (ttsContainer) {
      ttsContainer.insertAdjacentElement('afterend', toggle);
    } else {
      // Fallback: append at end of chat panel
      const chatPanel = document.querySelector('.chat-panel');
      chatPanel && chatPanel.appendChild(toggle);
    }
    toggle.addEventListener('click', () => {
      chatLog.classList.toggle('collapsed');
      if (chatLog.classList.contains('collapsed')) {
        toggle.classList.remove('expanded');
        toggle.innerHTML = '<span class="arrow">▼</span> Show more';
      } else {
        toggle.classList.add('expanded');
        toggle.innerHTML = '<span class="arrow">▲</span> Show less';
      }
      requestAnimationFrame(() => window.dispatchEvent(new Event('resize')));
    });
  }
}

// Women's health results
(function initWhExpand(){
  const whResults = document.getElementById('whResults');
  if (!whResults) return;
  whResults.classList.add('collapsed');
  let toggle = whResults.nextElementSibling;
  if (!toggle || !toggle.classList || !toggle.classList.contains('expand-toggle')) {
    toggle = document.createElement('button');
    toggle.className = 'expand-toggle';
    toggle.innerHTML = '<span class="arrow">▼</span> Show more';
    whResults.insertAdjacentElement('afterend', toggle);
    toggle.addEventListener('click', () => {
      whResults.classList.toggle('collapsed');
      if (whResults.classList.contains('collapsed')) {
        toggle.classList.remove('expanded');
        toggle.innerHTML = '<span class="arrow">▼</span> Show more';
      } else {
        toggle.classList.add('expanded');
        toggle.innerHTML = '<span class="arrow">▲</span> Show less';
      }
      requestAnimationFrame(() => window.dispatchEvent(new Event('resize')));
    });
  }
})();

// --- Women’s Health: query backend and render answer ---
(function initWomensHealth(){
  const whSearch = document.getElementById('whSearch');
  const whBtn = document.getElementById('whBtn');
  const whResults = document.getElementById('whResults');
  if (!whSearch || !whBtn || !whResults) return;

  function renderWh(data){
    const answer = data && data.answer ? String(data.answer) : '';
    const notice = data && data.notice ? String(data.notice) : '';
    whResults.innerHTML = '';
    const card = document.createElement('div');
    card.className = 'result-item';
    const ansEl = document.createElement('div');
    ansEl.textContent = answer || 'No answer available.';
    card.appendChild(ansEl);
    if (notice) {
      const note = document.createElement('p');
      note.className = 'fa-warn';
      note.textContent = notice;
      card.appendChild(note);
    }
    whResults.appendChild(card);
    // Collapsed by default with expand toggle
    whResults.classList.add('collapsed');
    let toggle = whResults.nextElementSibling;
    if (!toggle || !toggle.classList || !toggle.classList.contains('expand-toggle')) {
      toggle = document.createElement('button');
      toggle.className = 'expand-toggle';
      toggle.innerHTML = '<span class="arrow">▼</span> Show more';
      whResults.insertAdjacentElement('afterend', toggle);
      toggle.addEventListener('click', () => {
        whResults.classList.toggle('collapsed');
        if (whResults.classList.contains('collapsed')) {
          toggle.classList.remove('expanded');
          toggle.innerHTML = '<span class="arrow">▼</span> Show more';
        } else {
          toggle.classList.add('expanded');
          toggle.innerHTML = '<span class="arrow">▲</span> Show less';
        }
        requestAnimationFrame(() => window.dispatchEvent(new Event('resize')));
      });
    }
    // Initial height adjust
    requestAnimationFrame(() => window.dispatchEvent(new Event('resize')));
  }

  async function doWhSearch(){
    const q = (whSearch.value || '').trim();
    if (!q) { whResults.innerHTML = '<p>Please enter a topic (e.g., PCOS, periods, pelvic pain, pregnancy).</p>'; return; }
    whResults.innerHTML = '<p>Analyzing your question…</p>';
    try {
      const lang = (languageSel?.value) || 'en';
      const payload = { query: q, language: lang, history: chatHistory.slice(-6) };
      const res = await fetch('/api/womens-health', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const data = await res.json();
      renderWh(data || {});
    } catch (e) {
      whResults.innerHTML = '<p>Failed to fetch answer. Please try again.</p>';
    }
  }

  whBtn.addEventListener('click', doWhSearch);
  whSearch.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); doWhSearch(); } });
})();

if (starterAsk) starterAsk.addEventListener('click', () => prefillAndFocus('I have a headache and mild fever. What could be the possible causes and what should I do?'));
if (starterSymptoms) starterSymptoms.addEventListener('click', () => prefillAndFocus('I feel shortness of breath and chest tightness. Are these symptoms concerning?'));
if (starterMedicine) starterMedicine.addEventListener('click', () => prefillAndFocus('What is ibuprofen used for and what are its common side effects?'));
if (starterPreventive) starterPreventive.addEventListener('click', () => prefillAndFocus('What preventive tips can reduce the risk of type 2 diabetes?'));

// --- Slider Logic ---
(function initSlider(){
  if (!slider || !sliderTrack || !slides.length) return;
  let index = 0;
  let busy = false;
  function setViewportHeight() {
    if (!sliderViewport) return;
    const active = slides[index];
    if (!active) return;
    // Temporarily force natural height measurement
    const prev = sliderViewport.style.height;
    sliderViewport.style.height = active.offsetHeight + 'px';
  }
  function update() {
    const offset = -(index * 100);
    if (sliderViewport) sliderViewport.classList.add('sliding');
    busy = true;
    sliderTrack.style.transform = `translateX(${offset}%)`;
    setViewportHeight();
    // Disable while sliding
    if (sliderPrev) sliderPrev.disabled = true;
    if (sliderNext) sliderNext.disabled = true;
  }
  function onTransitionEnd(e){
    if (e.target !== sliderTrack) return;
    if (sliderViewport) sliderViewport.classList.remove('sliding');
    busy = false;
    if (sliderPrev) sliderPrev.disabled = false;
    if (sliderNext) sliderNext.disabled = false;
  }
  sliderTrack.addEventListener('transitionend', onTransitionEnd);
  if (sliderPrev) sliderPrev.addEventListener('click', () => {
    if (busy) return;
    index = (index - 1 + slides.length) % slides.length;
    update();
  });
  if (sliderNext) sliderNext.addEventListener('click', () => {
    if (busy) return;
    index = (index + 1) % slides.length;
    update();
  });
  // Keyboard arrows
  window.addEventListener('keydown', (e) => {
    if (busy) return;
    if (e.key === 'ArrowLeft') { index = (index - 1 + slides.length) % slides.length; update(); }
    if (e.key === 'ArrowRight') { index = (index + 1) % slides.length; update(); }
  });
  // Initialize disabled state
  if (sliderPrev) sliderPrev.disabled = false;
  if (sliderNext) sliderNext.disabled = slides.length <= 1 ? true : false;
  // Set initial height
  setViewportHeight();
  window.addEventListener('resize', setViewportHeight);
})();

// --- Theme (Auto/Light/Dark) ---
(() => {
  const root = document.documentElement;
  // Back-compat: migrate old 'theme' key to 'themeMode' if found
  (function migrateOldKey() {
    const legacy = localStorage.getItem('theme');
    const mode = localStorage.getItem('themeMode');
    if (!mode && (legacy === 'light' || legacy === 'dark')) {
      localStorage.setItem('themeMode', legacy);
      localStorage.removeItem('theme');
    }
  })();

  function effectiveTheme(mode) {
    if (mode === 'dark') return 'dark';
    if (mode === 'light') return 'light';
    const prefersDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
    return prefersDark ? 'dark' : 'light';
  }

  function setUiFor(mode) {
    const eff = effectiveTheme(mode);
    if (eff === 'dark') {
      root.classList.add('theme-dark');
      if (themeToggle) themeToggle.textContent = '☀️ Light';
    } else {
      root.classList.remove('theme-dark');
      if (themeToggle) themeToggle.textContent = '🌙 Dark';
    }
    if (themeModeSel && themeModeSel.value !== mode) themeModeSel.value = mode;
  }

  function applyMode(mode) {
    const normalized = (mode === 'dark' || mode === 'light') ? mode : 'auto';
    localStorage.setItem('themeMode', normalized);
    setUiFor(normalized);
  }

  function initTheme() {
    const savedMode = localStorage.getItem('themeMode');
    if (savedMode === 'light' || savedMode === 'dark' || savedMode === 'auto') {
      applyMode(savedMode);
    } else {
      applyMode('auto');
    }
  }
  if (themeToggle) {
    themeToggle.addEventListener('click', () => {
      // Toggle between explicit light/dark and exit Auto mode
      const isDark = document.documentElement.classList.contains('theme-dark');
      applyMode(isDark ? 'light' : 'dark');
    });
  }
  if (themeModeSel) {
    themeModeSel.addEventListener('change', (e) => {
      const val = e.target.value;
      applyMode(val);
    });
  }
  // Reflect changes if system theme changes and no manual preference saved
  if (window.matchMedia) {
    const mq = window.matchMedia('(prefers-color-scheme: dark)');
    mq.addEventListener?.('change', (e) => {
      const mode = localStorage.getItem('themeMode');
      if (mode !== 'light' && mode !== 'dark') {
        setUiFor('auto');
      }
    });
  }
  initTheme();
})();

// Deprecated UI elements (search, medication info, symptom checker)
const searchBox = document.getElementById('searchBox');
const searchBtn = document.getElementById('searchBtn');
const searchResults = document.getElementById('searchResults');
const symptomInput = document.getElementById('symptomInput');
const addSymptomBtn = document.getElementById('addSymptomBtn');
const symptomChips = document.getElementById('symptomChips');
const checkBtn = document.getElementById('checkBtn');
const checkerResults = document.getElementById('checkerResults');

// Hide deprecated sections if present
[searchBox, searchBtn, searchResults, symptomInput, addSymptomBtn, symptomChips, checkBtn, checkerResults]
  .filter(Boolean)
  .forEach((el) => { el.style.display = 'none'; });

let symptoms = [];

// Simple in-memory chat history (client-side) to provide prior context to backend
// Stores objects: { role: 'user'|'assistant', content: '...' }
const chatHistory = [];

function addMessage(text, who = 'bot') {
  const div = document.createElement('div');
  div.className = `message ${who}`;
  div.textContent = text;
  chatLog.appendChild(div);
  chatLog.scrollTop = chatLog.scrollHeight;
  // Recalculate slider height so the bottom toggle remains visible
  requestAnimationFrame(() => window.dispatchEvent(new Event('resize')));
  if (who === 'bot' && ttsToggle.checked && 'speechSynthesis' in window) {
    const lang = (ttsLanguageSel?.value) || (languageSel?.value) || 'en';
    // Prefer Google Cloud Telugu voice automatically when Telugu is selected
    if (ttsVoiceSel && lang === 'te') {
      const cloudVal = 'cloud:google:te-IN';
      const hasCloud = Array.from(ttsVoiceSel.options || []).some(o => o.value === cloudVal);
      if (hasCloud && !ttsVoiceSel.value) {
        ttsVoiceSel.value = cloudVal;
      }
    }
    // If Google cloud voice is selected, synthesize via backend
    if (ttsVoiceSel && String(ttsVoiceSel.value).startsWith('cloud:google:')) {
      try {
        fetch('/api/tts', {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ text, language: lang })
        }).then(r => r.json()).then(data => {
          if (data?.audio) {
            const audio = new Audio(data.audio);
            audio.play();
          } else {
            // Fallback to Web Speech if cloud fails
            const utter = new SpeechSynthesisUtterance(text);
            utter.lang = mapLangToBcp47(lang);
            speechSynthesis.speak(utter);
          }
        }).catch(() => {
          const utter = new SpeechSynthesisUtterance(text);
          utter.lang = mapLangToBcp47(lang);
          speechSynthesis.speak(utter);
        });
      } catch {
        const utter = new SpeechSynthesisUtterance(text);
        utter.lang = mapLangToBcp47(lang);
        speechSynthesis.speak(utter);
      }
    } else {
      const utter = new SpeechSynthesisUtterance(text);
      const bcp47 = mapLangToBcp47(lang);
      utter.lang = bcp47;
      const voices = speechSynthesis.getVoices();
      // If user chose a specific voice, use it; else pick a language-matching one
      let voice = null;
      if (ttsVoiceSel && ttsVoiceSel.value) {
        voice = voices.find(v => v.name === ttsVoiceSel.value);
      }
      if (!voice) {
        voice = voices.find(v => v.lang?.toLowerCase().startsWith(bcp47.toLowerCase()));
      }
      if (voice) utter.voice = voice;
      speechSynthesis.speak(utter);
    }
  }
}

// --- First Aid (Emergency and Urgent) ---
if (firstAidResults) {
  const FIRST_AID = [
    {
      key: 'cpr-adult', title: 'CPR (Adult)', severity: 'emergency',
      summary: 'No breathing or only gasping; unresponsive; no pulse.',
      steps: [
        'Call emergency services immediately.',
        'Begin chest compressions: center of chest, 100–120/min, depth ~5 cm, allow full recoil.',
        'After 30 compressions, give 2 rescue breaths if trained; otherwise, hands-only CPR.',
        'Continue until help arrives or victim shows signs of life.'
      ],
      warnings: ['Do not stop CPR unless relieved by a professional or the person recovers.']
    },
    {
      key: 'choking-adult', title: 'Choking (Adult/Child >1y)', severity: 'emergency',
      summary: 'Airway blocked: cannot speak/cough, silent, clutching throat.',
      steps: [
        'Ask: "Are you choking?" If yes and unable to speak, act immediately.',
        'Give 5 back blows between shoulder blades.',
        'Then 5 abdominal thrusts (Heimlich). Alternate 5 and 5 until object is expelled.',
        'If unresponsive, call emergency services and begin CPR.'
      ],
      warnings: ['Pregnant or obese: use chest thrusts instead of abdominal thrusts.']
    },
    {
      key: 'severe-bleeding', title: 'Severe Bleeding', severity: 'emergency',
      summary: 'Heavy bleeding that won’t stop; spurting blood; signs of shock.',
      steps: [
        'Call emergency services.',
        'Apply firm direct pressure with clean cloth/bandage.',
        'If soaked, add more layers; do not remove original dressing.',
        'Elevate limb if no fracture suspected. Use tourniquet if trained and bleeding is life-threatening.'
      ],
      warnings: ['Do not use a tourniquet unless trained or bleeding is life-threatening.']
    },
    {
      key: 'heart-attack', title: 'Heart Attack (Suspected)', severity: 'emergency',
      summary: 'Chest pressure, pain radiating to arm/jaw, sweating, nausea, shortness of breath.',
      steps: [
        'Call emergency services immediately.',
        'Have the person rest in a comfortable position.',
        'If not allergic and not contraindicated, chew 160–325 mg aspirin while awaiting help.',
        'Monitor breathing and be ready to start CPR if needed.'
      ],
      warnings: ['Do not give aspirin if allergic, recent bleeding, or advised against by a clinician.']
    },
    {
      key: 'stroke', title: 'Stroke (FAST: Face, Arm, Speech, Time)', severity: 'emergency',
      summary: 'Sudden facial droop, arm weakness, speech difficulty; time is critical.',
      steps: [
        'Call emergency services immediately.',
        'Note the time symptoms started.',
        'Keep the person safe and comfortable; do not give food or drink.'
      ],
      warnings: ['Do not delay transport; treatment window is time-sensitive.']
    },
    {
      key: 'anaphylaxis', title: 'Severe Allergic Reaction (Anaphylaxis)', severity: 'emergency',
      summary: 'Breathing difficulty, swelling, hives, low blood pressure after allergen exposure.',
      steps: [
        'Call emergency services.',
        'Use epinephrine auto-injector immediately if available; repeat in 5–15 minutes if needed.',
        'Lay the person flat with legs raised unless breathing is difficult; then allow comfortable position.',
        'Monitor breathing; be prepared for CPR.'
      ],
      warnings: ['Even if symptoms improve, medical evaluation is required.']
    },
    {
      key: 'burns', title: 'Burns (Mild to Moderate)', severity: 'urgent',
      summary: 'Redness, blistering from heat/scald; no airway involvement.',
      steps: [
        'Cool the burn under cool (not ice) running water for 10–20 minutes.',
        'Remove tight items (rings, bracelets) before swelling starts.',
        'Cover loosely with sterile non-adhesive dressing.',
        'Seek medical care if large, deep, or on face/genitals/hands/feet.'
      ],
      warnings: ['Do not apply ice, butter, toothpaste, or ointments to fresh burns.']
    },
    {
      key: 'fracture', title: 'Fracture/Suspected', severity: 'urgent',
      summary: 'Severe pain, swelling, deformity after injury.',
      steps: [
        'Immobilize the area using a splint or sling; keep the limb in the position found.',
        'Apply ice wrapped in cloth for swelling.',
        'Seek urgent medical evaluation; call emergency services if open fracture (bone visible) or severe deformity.'
      ],
      warnings: ['Do not attempt to realign bones.']
    },
    {
      key: 'asthma', title: 'Asthma Attack', severity: 'urgent',
      summary: 'Wheezing, shortness of breath, chest tightness; difficulty speaking full sentences.',
      steps: [
        'Use quick-relief inhaler (e.g., albuterol): 2–4 puffs via spacer every 20 minutes up to 1 hour as directed.',
        'Sit upright and focus on slow, deep breathing.',
        'Seek urgent care if no improvement or symptoms worsen.'
      ],
      warnings: ['If severe or lips turn blue, call emergency services immediately.']
    },
    {
      key: 'heatstroke', title: 'Heatstroke', severity: 'emergency',
      summary: 'Very high body temperature, confusion, hot/dry skin, possible loss of consciousness.',
      steps: [
        'Call emergency services.',
        'Move to a cool area, remove excess clothing.',
        'Cool rapidly: cool water immersion or pour cool water and fan, apply ice packs to neck/armpits/groin.'
      ],
      warnings: ['Do not give fluids if decreased consciousness or risk of aspiration.']
    },
    {
      key: 'seizure', title: 'Seizure (Active)', severity: 'urgent',
      summary: 'Jerking movements, unresponsiveness.',
      steps: [
        'Protect the head, clear area of hazards, gently roll to side after convulsions stop.',
        'Time the seizure. If >5 minutes or repeated seizures, call emergency services.',
        'Do not put anything in the mouth; do not restrain.'
      ],
      warnings: ['Seek medical evaluation after a first seizure or if injury occurred.']
    }
  ];

  function renderFirstAid(items) {
    firstAidResults.innerHTML = '';
    if (!items.length) { firstAidResults.innerHTML = '<p>No matching first aid topics.</p>'; return; }
    const wrap = document.createElement('div');
    items.forEach((it) => {
      const card = document.createElement('div');
      card.className = 'fa-card';
      const hdr = document.createElement('div');
      hdr.className = 'fa-header';
      const title = document.createElement('h3');
      title.textContent = it.title;
      const badge = document.createElement('span');
      badge.className = `fa-badge ${it.severity}`;
      badge.textContent = it.severity === 'emergency' ? 'Emergency' : 'Urgent';
      hdr.appendChild(title); hdr.appendChild(badge);
      const summary = document.createElement('p'); summary.className = 'fa-summary'; summary.textContent = it.summary;
      const details = document.createElement('details');
      const summaryTag = document.createElement('summary'); summaryTag.textContent = 'View steps';
      const steps = document.createElement('ol');
      it.steps.forEach(s => { const li = document.createElement('li'); li.textContent = s; steps.appendChild(li); });
      const warn = document.createElement('p'); warn.className = 'fa-warn'; warn.textContent = (it.warnings || []).join(' ');
      details.appendChild(summaryTag); details.appendChild(steps); if (it.warnings?.length) details.appendChild(warn);
      card.appendChild(hdr); card.appendChild(summary); card.appendChild(details);
      wrap.appendChild(card);
    });
    firstAidResults.appendChild(wrap);
    // Collapsed by default with expand toggle
    firstAidResults.classList.add('collapsed');
    let toggle = firstAidResults.nextElementSibling;
    if (!toggle || !toggle.classList.contains('expand-toggle')) {
      toggle = document.createElement('button');
      toggle.className = 'expand-toggle';
      toggle.innerHTML = '<span class="arrow">▼</span> Show more';
      firstAidResults.insertAdjacentElement('afterend', toggle);
      toggle.addEventListener('click', () => {
        const expanded = firstAidResults.classList.toggle('collapsed');
        if (firstAidResults.classList.contains('collapsed')) {
          toggle.classList.remove('expanded');
          toggle.innerHTML = '<span class="arrow">▼</span> Show more';
        } else {
          toggle.classList.add('expanded');
          toggle.innerHTML = '<span class="arrow">▲</span> Show less';
        }
        // Trigger slider height recalculation
        requestAnimationFrame(() => window.dispatchEvent(new Event('resize')));
      });
    }
    // Initial height adjust
    requestAnimationFrame(() => window.dispatchEvent(new Event('resize')));
  }

  function doFirstAidSearch() {
    const q = (firstAidSearch?.value || '').trim().toLowerCase();
    if (!q) {
      // Show emergency first by default
      const ordered = [...FIRST_AID].sort((a,b) => (a.severity === 'emergency' ? -1 : 1));
      renderFirstAid(ordered);
      return;
    }
    const res = FIRST_AID.filter(it =>
      it.title.toLowerCase().includes(q) ||
      it.summary.toLowerCase().includes(q) ||
      it.steps.some(s => s.toLowerCase().includes(q))
    ).sort((a,b) => (a.severity === 'emergency' ? -1 : 1));
    renderFirstAid(res);
  }

  // Events
  if (firstAidBtn) firstAidBtn.addEventListener('click', doFirstAidSearch);
  if (firstAidSearch) firstAidSearch.addEventListener('keydown', (e) => { if (e.key === 'Enter') doFirstAidSearch(); });
  // Initial render
  doFirstAidSearch();
}

async function sendMessage() {
  const msg = chatText.value.trim();
  if (!msg) return;
  addMessage(msg, 'user');
  chatText.value = '';
  chatHistory.push({ role: 'user', content: msg });
  try {
    const chatModeSel = document.getElementById('chatMode');
    const mode = (chatModeSel?.value) || 'medical';
    const endpoint = mode === 'general' ? '/api/ask' : (mode === 'biomedical' ? '/api/biomedical-chat' : '/api/chat-safe');
    const payload = mode === 'general'
      ? { question: msg, language: languageSel?.value || 'en', history: chatHistory.slice(-10) }
      : (mode === 'biomedical'
          ? { question: msg, language: languageSel?.value || 'en', history: chatHistory.slice(-10) }
          : { message: msg, demographic: demographicSel.value, language: languageSel?.value || 'en', history: chatHistory.slice(-10) });
    const res = await fetch(endpoint, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    let data = null;
    try { data = await res.json(); } catch {}
    if (!res.ok) {
      const errMsg = (data && (data.error || data.message || data.details)) || `Request failed (${res.status})`;
      addMessage(String(errMsg || 'Error')); 
      chatHistory.push({ role: 'assistant', content: String(errMsg || 'Error') });
      return;
    }
    const answer = (data && (data.answer || data.message)) || 'No answer.';
    addMessage(answer);
    chatHistory.push({ role: 'assistant', content: answer });
  } catch (e) {
    addMessage('Error contacting server.');
  }
}

sendBtn.addEventListener('click', sendMessage);
chatText.addEventListener('keydown', (e) => { if (e.key === 'Enter') sendMessage(); });

// Web Speech API for mic input
let recognition = null;
if ('webkitSpeechRecognition' in window) {
  const SR = window.webkitSpeechRecognition;
  recognition = new SR();
  recognition.lang = mapLangToBcp47(languageSel?.value || 'en');
  recognition.interimResults = false;
  recognition.maxAlternatives = 1;
  recognition.onresult = (e) => {
    const transcript = e.results[0][0].transcript;
    chatText.value = transcript;
    sendMessage();
  };
  recognition.onerror = () => { addMessage('Voice input error.'); };
}

micBtn.addEventListener('click', () => {
  if (!recognition) {
    addMessage('Voice input not supported in this browser.');
    return;
  }
  recognition.lang = mapLangToBcp47(languageSel?.value || 'en');
  recognition.start();
});

// Update TTS voices list before first speak
if ('speechSynthesis' in window) {
  function populateVoices() {
    if (!ttsVoiceSel) return;
    const lang = (ttsLanguageSel?.value) || (languageSel?.value) || 'en';
    const bcp47 = mapLangToBcp47(lang).toLowerCase();
    const voices = window.speechSynthesis.getVoices() || [];
    // filter voices by language, fallback to all if none
    const filtered = voices.filter(v => String(v.lang || '').toLowerCase().startsWith(bcp47));
    let list = filtered.length ? filtered : voices;
    const prev = ttsVoiceSel.value;
    ttsVoiceSel.innerHTML = '';
    // Offer Google Telugu (Cloud) option when Telugu selected
    if (lang === 'te') {
      const cloudOpt = document.createElement('option');
      cloudOpt.value = 'cloud:google:te-IN';
      cloudOpt.textContent = 'Google Telugu (Cloud)';
      ttsVoiceSel.appendChild(cloudOpt);
    }
    // If user requested Telugu but no local Telugu voices are found, show a hint option as well
    if (!filtered.length && lang === 'te') {
      const optInfo = document.createElement('option');
      optInfo.value = '';
      optInfo.textContent = 'No local Telugu voice found';
      optInfo.disabled = true;
      ttsVoiceSel.appendChild(optInfo);
    }
    // Prefer voices that explicitly mention the target language in their name
    list = list.sort((a,b) => {
      const an = (a.name||'').toLowerCase();
      const bn = (b.name||'').toLowerCase();
      const al = (a.lang||'').toLowerCase();
      const bl = (b.lang||'').toLowerCase();
      const preferA = (al.startsWith(bcp47) || an.includes('telugu')) ? 1 : 0;
      const preferB = (bl.startsWith(bcp47) || bn.includes('telugu')) ? 1 : 0;
      return preferB - preferA;
    });
    list.forEach(v => {
      const opt = document.createElement('option');
      opt.value = v.name;
      opt.textContent = `${v.name} (${v.lang})`;
      ttsVoiceSel.appendChild(opt);
    });
    // Selection priority:
    // 1) Preserve previous selection if available
    // 2) If Telugu and Cloud option exists, default to Cloud Telugu
    // 3) Otherwise pick first preferred local voice
    const optsArr = Array.from(ttsVoiceSel.options);
    const hasPrev = prev && optsArr.some(o => o.value === prev);
    const hasCloudTe = optsArr.some(o => o.value === 'cloud:google:te-IN');
    if (hasPrev) {
      ttsVoiceSel.value = prev;
    } else if (lang === 'te' && hasCloudTe) {
      ttsVoiceSel.value = 'cloud:google:te-IN';
    } else if (list[0]) {
      // Auto-pick the first preferred voice (likely target language)
      ttsVoiceSel.value = list[0].name || '';
    }
  }
  // Some browsers need a voiceschanged event to populate voices
  window.speechSynthesis.onvoiceschanged = populateVoices;
  // Populate initially (may be empty, will fill on voiceschanged)
  populateVoices();
  // Re-filter voices when the language dropdown changes
  if (languageSel) languageSel.addEventListener('change', populateVoices);
  if (ttsLanguageSel) ttsLanguageSel.addEventListener('change', populateVoices);
}

// Populate Speech Language list from the chat language list
(function initSpeechLanguageList(){
  if (!ttsLanguageSel || !languageSel) return;
  function fillFromLanguageSel() {
    const opts = Array.from(languageSel.options).map(o => ({ value: o.value, label: o.text }));
    const prev = ttsLanguageSel.value || languageSel.value || 'en';
    ttsLanguageSel.innerHTML = '';
    opts.forEach(({ value, label }) => {
      const opt = document.createElement('option');
      opt.value = value; opt.textContent = label; ttsLanguageSel.appendChild(opt);
    });
    ttsLanguageSel.value = prev;
  }
  fillFromLanguageSel();
})();

// --- Language search & filter ---
if (languageSel && languageSearch) {
  const allOptions = Array.from(languageSel.options).map((o) => ({ value: o.value, label: o.text }));

  function renderOptions(list, keepValue) {
    const prev = keepValue && list.some(o => o.value === keepValue) ? keepValue : (list[0]?.value || 'en');
    languageSel.innerHTML = '';
    list.forEach(({ value, label }) => {
      const opt = document.createElement('option');
      opt.value = value;
      opt.textContent = label;
      languageSel.appendChild(opt);
    });
    if (prev) languageSel.value = prev;
  }

  function normalize(s) { return (s || '').toLowerCase(); }

  function filterLanguages(query) {
    const q = normalize(query);
    if (!q) { renderOptions(allOptions, languageSel.value); return; }
    // Match against value and label, prioritize startsWith then includes
    const starts = allOptions.filter(o => normalize(o.label).startsWith(q) || normalize(o.value).startsWith(q));
    const contains = allOptions.filter(o => !starts.includes(o) && (normalize(o.label).includes(q) || normalize(o.value).includes(q)));
    const result = [...starts, ...contains];
    renderOptions(result.length ? result : allOptions, languageSel.value);
  }

  languageSearch.addEventListener('input', (e) => {
    filterLanguages(e.target.value);
  });

  languageSearch.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      const q = e.target.value.trim();
      if (!q) return;
      const opts = Array.from(languageSel.options);
      const first = opts[0];
      if (first) {
        languageSel.value = first.value;
        e.preventDefault();
        languageSel.focus();
      }
    }
  });
}

// --- Nearby Hospitals ---
if (findHospitalsBtn && hospitalResults) {
  findHospitalsBtn.addEventListener('click', () => {
    hospitalResults.innerHTML = '<p>Detecting your location…</p>';
    if (!navigator.geolocation) {
      hospitalResults.innerHTML = '<p>Geolocation is not supported by your browser.</p>';
      return;
    }
    navigator.geolocation.getCurrentPosition(async (pos) => {
      const { latitude: lat, longitude: lon } = pos.coords;
      if (userCoordsEl) userCoordsEl.textContent = `Your location: ${lat.toFixed(5)}, ${lon.toFixed(5)}`;
      hospitalResults.innerHTML = '<p>Searching for nearby hospitals…</p>';
      try {
        const rad = parseInt(hospitalRadius?.value || '3000', 10) || 3000;
        const q = (hospitalQuery?.value || '').trim();
        const res = await fetch(`/api/nearby-hospitals?lat=${encodeURIComponent(lat)}&lon=${encodeURIComponent(lon)}&radius=${encodeURIComponent(rad)}${q ? `&q=${encodeURIComponent(q)}` : ''}`);
        const data = await res.json();
        renderHospitals(data, lat, lon, rad);
      } catch (e) {
        hospitalResults.innerHTML = '<p>Failed to fetch hospitals.</p>';
      }
    }, (err) => {
      const msg = err && err.message ? err.message : 'Unable to retrieve your location.';
      hospitalResults.innerHTML = `<p>${msg}</p>`;
    }, { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 });
  });

  // Press Enter in the Issue field to trigger search
  if (hospitalQuery) {
    hospitalQuery.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        findHospitalsBtn.click();
      }
    });
  }

  function renderHospitals(data, userLat, userLon, radiusMeters) {
    let items = Array.isArray(data?.hospitals) ? data.hospitals : [];
    if (!items.length) {
      const km = Math.max(1, Math.round((radiusMeters || 3000) / 1000));
      hospitalResults.innerHTML = `<p>No hospitals found nearby within ${km} km.</p>`;
      return;
    }
    // Compute distance and sort by relevance (matchScore desc if present), then distance asc
    items = items.map(h => ({ ...h, _dist: haversine(userLat, userLon, h.lat, h.lon) }))
                 .sort((a, b) => ((b.matchScore || 0) - (a.matchScore || 0)) || (a._dist - b._dist));
    const list = document.createElement('div');
    list.className = 'hospital-list';
    items.forEach((h) => {
      const div = document.createElement('div');
      div.className = 'result-item';
      const title = document.createElement('h3');
      title.classList.add('hospital-title');
      // Add animated hospital icon (medical cross)
      const hospIcon = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
      hospIcon.setAttribute('width', '18');
      hospIcon.setAttribute('height', '18');
      hospIcon.setAttribute('viewBox', '0 0 24 24');
      hospIcon.setAttribute('fill', 'none');
      hospIcon.setAttribute('stroke', 'currentColor');
      hospIcon.setAttribute('stroke-width', '2');
      hospIcon.setAttribute('stroke-linecap', 'round');
      hospIcon.setAttribute('stroke-linejoin', 'round');
      hospIcon.classList.add('pin-bounce');
      const rect = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
      rect.setAttribute('x', '3'); rect.setAttribute('y', '3'); rect.setAttribute('width', '18'); rect.setAttribute('height', '18'); rect.setAttribute('rx', '2');
      const v = document.createElementNS('http://www.w3.org/2000/svg', 'line'); v.setAttribute('x1', '12'); v.setAttribute('y1', '7'); v.setAttribute('x2', '12'); v.setAttribute('y2', '17');
      const hline = document.createElementNS('http://www.w3.org/2000/svg', 'line'); hline.setAttribute('x1', '7'); hline.setAttribute('y1', '12'); hline.setAttribute('x2', '17'); hline.setAttribute('y2', '12');
      hospIcon.appendChild(rect); hospIcon.appendChild(v); hospIcon.appendChild(hline);
      const nameText = document.createTextNode(' ' + (h.name || 'Unnamed Hospital'));
      title.appendChild(hospIcon);
      title.appendChild(nameText);
      const meta = document.createElement('p');
      const distance = h._dist;
      const distStr = distance < 1 ? `${Math.round(distance * 1000)} m` : `${distance.toFixed(2)} km`;
      const coordStr = `(${h.lat.toFixed(5)}, ${h.lon.toFixed(5)})`;
      meta.textContent = `${h.address || 'Address not available'} • ${distStr} • ${coordStr}`;
      // specialties badges and match score if available
      if (Array.isArray(h.specialties) && h.specialties.length) {
        const specs = document.createElement('p');
        specs.className = 'hospital-specs';
        h.specialties.slice(0, 6).forEach(s => {
          const b = document.createElement('span');
          b.className = 'badge';
          b.textContent = s;
          specs.appendChild(b);
          specs.appendChild(document.createTextNode(' '));
        });
        if (typeof h.matchScore === 'number' && h.matchScore > 0) {
          const score = document.createElement('span');
          score.className = 'badge badge-accent';
          score.textContent = `match ${h.matchScore}`;
          specs.appendChild(score);
        }
        div.appendChild(specs);
      }
      const links = document.createElement('p');
      links.className = 'map-link';
      const mapsUrl = `https://www.google.com/maps?q=${encodeURIComponent(h.lat + ',' + h.lon)}(${encodeURIComponent(h.name || 'Hospital')})`;
      const pin = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
      pin.setAttribute('width', '16'); pin.setAttribute('height', '16'); pin.setAttribute('viewBox', '0 0 24 24');
      pin.setAttribute('fill', 'none'); pin.setAttribute('stroke', 'currentColor'); pin.setAttribute('stroke-width', '2');
      pin.setAttribute('stroke-linecap', 'round'); pin.setAttribute('stroke-linejoin', 'round'); pin.classList.add('pin-bounce');
      const pinPath = document.createElementNS('http://www.w3.org/2000/svg', 'path'); pinPath.setAttribute('d', 'M21 10c0 6-9 12-9 12S3 16 3 10a9 9 0 1 1 18 0Z');
      const pinCircle = document.createElementNS('http://www.w3.org/2000/svg', 'circle'); pinCircle.setAttribute('cx', '12'); pinCircle.setAttribute('cy', '10'); pinCircle.setAttribute('r', '3');
      pin.appendChild(pinPath); pin.appendChild(pinCircle);
      const a = document.createElement('a'); a.href = mapsUrl; a.target = '_blank'; a.rel = 'noopener'; a.textContent = 'Open in Maps';
      links.appendChild(pin);
      links.appendChild(a);
      if (h.phone) {
        const ph = document.createElement('span');
        const phoneIcon = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
        phoneIcon.setAttribute('width', '16'); phoneIcon.setAttribute('height', '16'); phoneIcon.setAttribute('viewBox', '0 0 24 24');
        phoneIcon.setAttribute('fill', 'none'); phoneIcon.setAttribute('stroke', 'currentColor'); phoneIcon.setAttribute('stroke-width', '2');
        phoneIcon.setAttribute('stroke-linecap', 'round'); phoneIcon.setAttribute('stroke-linejoin', 'round'); phoneIcon.classList.add('pin-bounce');
        const phPath1 = document.createElementNS('http://www.w3.org/2000/svg', 'path'); phPath1.setAttribute('d', 'M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6A19.79 19.79 0 0 1 2.09 4.18 2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.66 12.66 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.66 12.66 0 0 0 2.81.7A2 2 0 0 1 22 16.92Z');
        phoneIcon.appendChild(phPath1);
        ph.appendChild(document.createTextNode('  '));
        ph.appendChild(phoneIcon);
        ph.appendChild(document.createTextNode(' ' + h.phone));
        links.appendChild(ph);
      }
      if (h.website) { const ws = document.createElement('a'); ws.href = h.website; ws.target = '_blank'; ws.rel = 'noopener'; ws.textContent = ' • Website'; links.appendChild(ws); }
      div.appendChild(title);
      div.appendChild(meta);
      div.appendChild(links);
      list.appendChild(div);
    });
    hospitalResults.innerHTML = '';
    hospitalResults.appendChild(list);
    // Collapsed by default with expand toggle
    hospitalResults.classList.add('collapsed');
    let toggle = hospitalResults.nextElementSibling;
    if (!toggle || !toggle.classList.contains('expand-toggle')) {
      toggle = document.createElement('button');
      toggle.className = 'expand-toggle';
      toggle.innerHTML = '<span class="arrow">▼</span> Show more';
      hospitalResults.insertAdjacentElement('afterend', toggle);
      toggle.addEventListener('click', () => {
        const expanded = hospitalResults.classList.toggle('collapsed');
        if (hospitalResults.classList.contains('collapsed')) {
          toggle.classList.remove('expanded');
          toggle.innerHTML = '<span class="arrow">▼</span> Show more';
        } else {
          toggle.classList.add('expanded');
          toggle.innerHTML = '<span class="arrow">▲</span> Show less';
        }
        // Trigger slider height recalculation
        requestAnimationFrame(() => window.dispatchEvent(new Event('resize')));
      });
    }
    // Initial height adjust
    requestAnimationFrame(() => window.dispatchEvent(new Event('resize')));
  }

  function haversine(lat1, lon1, lat2, lon2) {
    function toRad(d) { return d * Math.PI / 180; }
    const R = 6371; // km
    const dLat = toRad(lat2 - lat1);
    const dLon = toRad(lon2 - lon1);
    const a = Math.sin(dLat/2) * Math.sin(dLat/2) + Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon/2) * Math.sin(dLon/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
  }
}

function mapLangToBcp47(code) {
  const map = {
    af: 'af-ZA',
    sq: 'sq-AL',
    am: 'am-ET',
    ar: 'ar-SA',
    hy: 'hy-AM',
    as: 'as-IN',
    az: 'az-Latn-AZ',
    eu: 'eu-ES',
    be: 'be-BY',
    bn: 'bn-IN',
    bs: 'bs-BA',
    bg: 'bg-BG',
    my: 'my-MM',
    ca: 'ca-ES',
    'zh-CN': 'zh-CN',
    'zh-TW': 'zh-TW',
    hr: 'hr-HR',
    cs: 'cs-CZ',
    da: 'da-DK',
    nl: 'nl-NL',
    en: 'en-US',
    et: 'et-EE',
    fa: 'fa-IR',
    fi: 'fi-FI',
    fr: 'fr-FR',
    gl: 'gl-ES',
    ka: 'ka-GE',
    de: 'de-DE',
    el: 'el-GR',
    gu: 'gu-IN',
    ha: 'ha-NG',
    he: 'he-IL',
    hi: 'hi-IN',
    brx: 'brx-IN',
    doi: 'doi-IN',
    hu: 'hu-HU',
    is: 'is-IS',
    id: 'id-ID',
    ga: 'ga-IE',
    it: 'it-IT',
    ja: 'ja-JP',
    kn: 'kn-IN',
    kok: 'kok-IN',
    ks: 'ks-Arab-IN',
    mai: 'mai-IN',
    kk: 'kk-KZ',
    km: 'km-KH',
    ko: 'ko-KR',
    ky: 'ky-KG',
    lo: 'lo-LA',
    lv: 'lv-LV',
    lt: 'lt-LT',
    mk: 'mk-MK',
    ms: 'ms-MY',
    ml: 'ml-IN',
    mt: 'mt-MT',
    mr: 'mr-IN',
    mni: 'mni-IN',
    mn: 'mn-MN',
    ne: 'ne-NP',
    nb: 'nb-NO',
    nn: 'nn-NO',
    or: 'or-IN',
    ps: 'ps-AF',
    pl: 'pl-PL',
    'pt-BR': 'pt-BR',
    'pt-PT': 'pt-PT',
    pa: 'pa-IN',
    sa: 'sa-IN',
    sat: 'sat-IN',
    sd: 'sd-Arab-IN',
    ro: 'ro-RO',
    ru: 'ru-RU',
    sr: 'sr-RS',
    si: 'si-LK',
    sk: 'sk-SK',
    sl: 'sl-SI',
    so: 'so-SO',
    'es-ES': 'es-ES',
    'es-MX': 'es-MX',
    sw: 'sw-KE',
    sv: 'sv-SE',
    tl: 'tl-PH',
    ta: 'ta-IN',
    te: 'te-IN',
    th: 'th-TH',
    tr: 'tr-TR',
    uk: 'uk-UA',
    ur: 'ur-PK',
    uz: 'uz-UZ',
    vi: 'vi-VN',
    xh: 'xh-ZA',
    yo: 'yo-NG',
    zu: 'zu-ZA',
  };
  return map[code] || 'en-US';
}

// --- Explore Panel (Search, Symptom Checker, Medication Lookup) ---
(() => {
  const expSearchInput = document.getElementById('expSearchInput');
  const expSearchBtn = document.getElementById('expSearchBtn');
  const expSearchResults = document.getElementById('expSearchResults');
  const expSymptomInput = document.getElementById('expSymptomInput');
  const expAddSymptomBtn = document.getElementById('expAddSymptomBtn');
  const expSymptomChips = document.getElementById('expSymptomChips');
  const expCheckBtn = document.getElementById('expCheckBtn');
  const expCheckerResults = document.getElementById('expCheckerResults');
  const expMedInput = document.getElementById('expMedInput');
  const expMedBtn = document.getElementById('expMedBtn');
  const expMedResults = document.getElementById('expMedResults');

  if (!document.querySelector('.explore-panel')) return;

  // Local state for explore symptoms
  const exploreSymptoms = [];

  function renderChips() {
    if (!expSymptomChips) return;
    expSymptomChips.innerHTML = '';
    exploreSymptoms.forEach((s, idx) => {
      const chip = document.createElement('span');
      chip.className = 'chip';
      chip.textContent = s;
      const x = document.createElement('button');
      x.className = 'chip-x';
      x.setAttribute('aria-label', `Remove ${s}`);
      x.textContent = '';
      x.addEventListener('click', () => {
        exploreSymptoms.splice(idx, 1);
        renderChips();
      });
      chip.appendChild(document.createTextNode(' '));
      chip.appendChild(x);
      expSymptomChips.appendChild(chip);
    });
  }

  function addSymptom() {
    const val = (expSymptomInput?.value || '').trim();
    if (!val) return;
    if (!exploreSymptoms.includes(val)) exploreSymptoms.push(val);
    expSymptomInput.value = '';
    renderChips();
  }

  // Search handler
  async function doExploreSearch() {
    const q = (expSearchInput?.value || '').trim();
    if (!q) { expSearchResults.innerHTML = '<p>Please enter a search term.</p>'; return; }
    expSearchResults.innerHTML = '<p>Searching</p>';
    try {
      const demo = demographicSel?.value || 'general';
      const res = await fetch(`/api/search?q=${encodeURIComponent(q)}&demographic=${encodeURIComponent(demo)}`);
      const data = await res.json();
      const results = Array.isArray(data?.results) ? data.results : [];
      if (!results.length) { expSearchResults.innerHTML = '<p>No results.</p>'; return; }
      const wrap = document.createElement('div');
      results.forEach((r) => {
        const item = document.createElement('div');
        item.className = 'result-item';
        const h = document.createElement('h3');
        h.textContent = `${r.type}: ${r.name}`;
        const p = document.createElement('p');
        p.textContent = r.text || '';
        item.appendChild(h); item.appendChild(p);
        if (r.demographic_notes) {
          const note = document.createElement('p');
          note.className = 'fa-warn';
          note.textContent = r.demographic_notes;
          item.appendChild(note);
        }
        wrap.appendChild(item);
      });
      expSearchResults.innerHTML = '';
      expSearchResults.appendChild(wrap);
    } catch (e) {
      expSearchResults.innerHTML = '<p>Search failed. Please try again.</p>';
    }
  }

  // Symptom check handler
  async function doExploreCheck() {
    if (!exploreSymptoms.length) { expCheckerResults.innerHTML = '<p>Add at least one symptom.</p>'; return; }
    expCheckerResults.innerHTML = '<p>Checking</p>';
    try {
      const demo = demographicSel?.value || 'general';
      const res = await fetch('/api/symptoms/check', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ symptoms: exploreSymptoms, demographic: demo })
      });
      const data = await res.json();
      const results = Array.isArray(data?.results) ? data.results : [];
      if (!results.length) {
        const msg = data?.message || 'No matches.';
        expCheckerResults.innerHTML = `<p>${msg}</p>`;
        return;
      }
      const wrap = document.createElement('div');
      results.forEach((r) => {
        const item = document.createElement('div');
        item.className = 'result-item';
        const h = document.createElement('h3');
        h.textContent = `${r.disease.name} (score ${r.score})`;
        const p = document.createElement('p');
        p.textContent = r.disease.description || '';
        item.appendChild(h); item.appendChild(p);
        if (Array.isArray(r.matchedSymptoms) && r.matchedSymptoms.length) {
          const m = document.createElement('p');
          m.textContent = 'Matched: ' + r.matchedSymptoms.map(ms => `${ms.name}${ms.commonality ? ` (${ms.commonality})` : ''}`).join(', ');
          item.appendChild(m);
        }
        if (r.demographic_notes) {
          const note = document.createElement('p');
          note.className = 'fa-warn';
          note.textContent = r.demographic_notes;
          item.appendChild(note);
        }
        wrap.appendChild(item);
      });
      expCheckerResults.innerHTML = '';
      expCheckerResults.appendChild(wrap);
    } catch (e) {
      expCheckerResults.innerHTML = '<p>Symptom check failed. Please try again.</p>';
    }
  }

  // Medication lookup handler
  async function doExploreMed() {
    const name = (expMedInput?.value || '').trim();
    if (!name) { expMedResults.innerHTML = '<p>Please enter a medication name.</p>'; return; }
    expMedResults.innerHTML = '<p>Looking up</p>';
    try {
      const res = await fetch(`/api/medications/${encodeURIComponent(name)}`);
      const data = await res.json();
      const med = data?.medication || null;
      const related = Array.isArray(data?.relatedDiseases) ? data.relatedDiseases : [];
      const wrap = document.createElement('div');
      const card = document.createElement('div');
      card.className = 'result-item';
      const h = document.createElement('h3');
      h.textContent = med ? med.name : 'No exact match';
      card.appendChild(h);
      if (med) {
        ['generic_name','uses','dosage','side_effects','warnings'].forEach((k) => {
          if (med[k]) { const p = document.createElement('p'); p.textContent = `${k.replace('_',' ')}: ${med[k]}`; card.appendChild(p); }
        });
      } else if (data?.message) {
        const p = document.createElement('p'); p.textContent = data.message; card.appendChild(p);
      }
      if (related.length) {
        const rel = document.createElement('p');
        rel.textContent = 'Related diseases: ' + related.map(d => d.name).join(', ');
        card.appendChild(rel);
      }
      if (data?.notice) {
        const note = document.createElement('p'); note.className = 'fa-warn'; note.textContent = data.notice; card.appendChild(note);
      }
      wrap.appendChild(card);
      expMedResults.innerHTML = '';
      expMedResults.appendChild(wrap);
    } catch (e) {
      expMedResults.innerHTML = '<p>Medication lookup failed. Please try again.</p>';
    }
  }

  // Wire events
  expSearchBtn && expSearchBtn.addEventListener('click', doExploreSearch);
  expSearchInput && expSearchInput.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); doExploreSearch(); } });
  expAddSymptomBtn && expAddSymptomBtn.addEventListener('click', addSymptom);
  expSymptomInput && expSymptomInput.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); addSymptom(); } });
  expCheckBtn && expCheckBtn.addEventListener('click', doExploreCheck);
  expMedBtn && expMedBtn.addEventListener('click', doExploreMed);
  expMedInput && expMedInput.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); doExploreMed(); } });
})();
// --- Explore polish: collapsible results, skeleton loaders, debounced search ---
(() => {
  const expSearchResults = document.getElementById('expSearchResults');
  const expCheckerResults = document.getElementById('expCheckerResults');
  const expMedResults = document.getElementById('expMedResults');
  const expSearchBtn = document.getElementById('expSearchBtn');
  const expSearchInput = document.getElementById('expSearchInput');
  const expCheckBtn = document.getElementById('expCheckBtn');
  const expMedBtn = document.getElementById('expMedBtn');

  if (!document.querySelector('.explore-panel')) return;

  function setSkeleton(el) {
    if (!el) return;
    el.innerHTML = '<div class="skeleton">\
      <div class="skeleton-line w-80"></div>\
      <div class="skeleton-line"></div>\
      <div class="skeleton-line w-60"></div>\
    </div>';
  }

  function installCollapsible(el) {
    if (!el) return;
    // Collapse and add toggle if not exists
    el.classList.add('collapsed');
    let toggle = el.nextElementSibling;
    if (!toggle || !toggle.classList || !toggle.classList.contains('expand-toggle')) {
      toggle = document.createElement('button');
      toggle.className = 'expand-toggle';
      toggle.innerHTML = '<span class="arrow"></span> Show more';
      el.insertAdjacentElement('afterend', toggle);
      toggle.addEventListener('click', () => {
        el.classList.toggle('collapsed');
        if (el.classList.contains('collapsed')) {
          toggle.classList.remove('expanded');
          toggle.innerHTML = '<span class="arrow"></span> Show more';
        } else {
          toggle.classList.add('expanded');
          toggle.innerHTML = '<span class="arrow"></span> Show less';
        }
        requestAnimationFrame(() => window.dispatchEvent(new Event('resize')));
      });
    }
  }

  // Observe result containers and (re)install collapsible toggle when content changes
  [expSearchResults, expCheckerResults, expMedResults].forEach((el) => {
    if (!el) return;
    installCollapsible(el);
    const mo = new MutationObserver(() => {
      if (el.childElementCount > 0) installCollapsible(el);
    });
    mo.observe(el, { childList: true });
  });

  // Prepend skeletons before existing handlers via capture-phase listeners
  if (expSearchBtn && expSearchResults) {
    expSearchBtn.addEventListener('click', () => setSkeleton(expSearchResults), { capture: true });
  }
  if (expCheckBtn && expCheckerResults) {
    expCheckBtn.addEventListener('click', () => setSkeleton(expCheckerResults), { capture: true });
  }
  if (expMedBtn && expMedResults) {
    expMedBtn.addEventListener('click', () => setSkeleton(expMedResults), { capture: true });
  }

  // Debounced search on input
  function debounce(fn, ms) { let t; return function(...args){ clearTimeout(t); t = setTimeout(() => fn.apply(this, args), ms); }; }
  if (expSearchInput && expSearchBtn && expSearchResults) {
    const debounced = debounce(() => {
      const q = (expSearchInput.value || '').trim();
      if (!q) return;
      setSkeleton(expSearchResults);
      expSearchBtn.click();
    }, 500);
    expSearchInput.addEventListener('input', debounced);
  }
})();
// --- Extended search override to include chemicals and enzymes ---
(() => {
  const btn = document.getElementById('expSearchBtn');
  const input = document.getElementById('expSearchInput');
  const out = document.getElementById('expSearchResults');
  if (!btn || !input || !out) return;

  async function doExtendedSearch() {
    const q = (input.value || '').trim();
    if (!q) { out.innerHTML = '<p>Please enter a search term.</p>'; return; }
    // show skeleton (if styles present)
    out.innerHTML = '<div class="skeleton">\
      <div class="skeleton-line w-80"></div>\
      <div class="skeleton-line"></div>\
      <div class="skeleton-line w-60"></div>\
    </div>';
    try {
      const demo = (document.getElementById('demographic')?.value) || 'general';
      const res = await fetch(`/api/search-extended?q=${encodeURIComponent(q)}&demographic=${encodeURIComponent(demo)}`);
      const data = await res.json();
      const results = Array.isArray(data?.results) ? data.results : [];
      if (!results.length) { out.innerHTML = '<p>No results.</p>'; return; }
      const wrap = document.createElement('div');
      results.forEach((r) => {
        const item = document.createElement('div');
        item.className = 'result-item';
        const h = document.createElement('h3');
        const type = document.createElement('span');
        type.className = 'badge type-badge';
        type.textContent = r.type;
        h.appendChild(type);
        h.appendChild(document.createTextNode(' ' + r.name));
        item.appendChild(h);
        if (r.category) {
          const cat = document.createElement('p');
          cat.className = 'muted';
          cat.textContent = r.category;
          item.appendChild(cat);
        }
        if (r.text) {
          const p = document.createElement('p');
          p.textContent = r.text;
          item.appendChild(p);
        }
        if (r.demographic_notes) {
          const note = document.createElement('p'); note.className = 'fa-warn'; note.textContent = r.demographic_notes; item.appendChild(note);
        }
        wrap.appendChild(item);
      });
      out.innerHTML = '';
      out.appendChild(wrap);
    } catch (e) {
      out.innerHTML = '<p>Search failed. Please try again.</p>';
    }
  }

  // Capture-phase override: run extended search and stop earlier click handlers
  btn.addEventListener('click', (evt) => {
    evt.stopPropagation();
    evt.preventDefault();
    doExtendedSearch();
  }, { capture: true });
})();
